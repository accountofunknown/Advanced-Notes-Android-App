// Plugins are declared here (not applied) so every module uses the same versions.
// The Compose compiler plugin below also pulls in Kotlin 2.4.21, which AGP 9's
// built-in Kotlin support then uses.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.ksp) apply false
    alias(libs.plugins.hilt) apply false
}
