# Advanced Notes (v0.01 - milestones M01-M03)

An offline-first Android notes app: Kotlin, Jetpack Compose, Material 3, Room, Hilt.
No account, no internet, **no permissions**, no analytics.

## What works in this first drop
- Project foundation: Gradle version catalog, Hilt, Room, DataStore, Compose (M01).
- Design system and navigation: AMOLED Black / Dark / Light / System themes, accent colors, edge-to-edge, Home / Editor / Settings screens (M02).
- Database v1 (Room): notes, documents, notebooks, folders, tags, note-tags, revisions, with foreign keys and indexes (M03).
- A small working slice so the app is usable: create notes, edit title and text with **autosave** (Saved / Saving / Unsaved / Failed shown), word count, pin, move to Trash, restore, delete forever (with confirmation).

## Not built yet (later milestones)
Rich text and Markdown editors, folders/notebooks/tags screens, search (FTS), tasks and reminders, attachments, graph, security/encryption, import/export/backup, widgets, UI tests, database-migration tests. The database tables for most of these are not created yet; they will be added with real Room migrations.

## Project layout
Single `app` module for now (split into feature modules once there is enough code to justify it).
`core/` helpers, `data/` Room + repository, `di/` Hilt, `settings/` DataStore, `ui/` screens.

## Build on GitHub from your phone (no Android Studio)
1. Create a GitHub repository.
2. Upload **Advanced-Notes.zip** to the top level (root) of the repository. Do not unzip it.
3. Upload **android-build.yml** to `.github/workflows/android-build.yml` (use "Add file > Create new file", type the path `.github/workflows/android-build.yml`, paste the contents).
4. Open the **Actions** tab > **Android Build** > **Run workflow**. (It also runs on every push.)
5. When it finishes (a few minutes), open the run and download **advanced-notes-debug-apk** under *Artifacts*. Unzip it and install the APK (allow "install unknown apps" for your browser/file manager).
6. If the run fails, open the failed step, copy the error text and send it back - this is expected for a first build.

The workflow installs Gradle 9.8.2 itself and generates the Gradle wrapper if it is missing.

## Signed release APK (optional)
Add four repository secrets (Settings > Secrets and variables > Actions): `KEYSTORE_BASE64` (your keystore file, base64-encoded), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`. Without them the release build is skipped and the summary says so. Never put a keystore inside the ZIP.

## Run tests locally
`./gradlew testDebugUnitTest` (needs JDK 17 and the Android SDK). CI runs this on every build.

## Versions
AGP 9.5.1, Gradle 9.8.2, Kotlin 2.4.21, KSP 2.3.13, Hilt 2.60.1, Room 2.8.5, Compose 1.12.1, Material 3 1.4.0, Navigation 2.10.2, DataStore 1.3.0, JDK 17. compileSdk/targetSdk 37, minSdk 26.

## Known limitations
- **This code has not been compiled or built by its author yet** (no Android SDK or Gradle was available). The first GitHub Actions run is the first real build; expect to fix a few errors.
- `gradle-wrapper.jar` is not in the ZIP; CI generates it.
- No app icon yet (default Android icon).
- Release build is not minified (R8 off) in v0.01.
