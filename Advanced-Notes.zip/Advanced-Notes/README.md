# Advanced Notes (v0.01 - milestones M01-M05)

An offline-first Android notes app: Kotlin, Jetpack Compose, Material 3, Room, Hilt.
No account, no internet, **no permissions**, no analytics.

## What works now (M01-M05)
- Foundation (M01), design system and navigation (M02), Room database v1 (M03).
- **Note management (M04):** create Rich text or Plain text notes; autosave (Saved / Saving / Unsaved / Failed); pin, favorite, archive, duplicate, share (Android share sheet), Trash with restore and delete-forever confirmation; filters (Notes, Favorites, Archive, Trash); sorting (recently modified/created, title, oldest); **version history** (a snapshot at most every 5 minutes, up to 50 per note; view, restore, delete); undo/redo; find and replace.
- **Rich text editor (M05):** bold, italic, underline, strikethrough, highlight, 5 text colors, 3 sizes, headings (H1/H2/Body), bullet / numbered / checklist lines (Enter continues the list, Enter on an empty item ends it, "Tick" toggles a checkbox), divider line, word/character count and reading time. Formatting is stored with the note (JSON) and is restored when you reopen it.

## Not built yet (later milestones)
Markdown and plain-text-specific features (M06-M07), folders/notebooks/tags (M08), search (M09), tasks/reminders (M10), attachments, images, tables, links, code blocks and drawings (M11), knowledge graph (M12), lock/encryption (M13), import/export/backup (M14), widgets (M15), UI and migration tests (M16). Also not yet: paragraph alignment, comparing two versions side by side, merging notes, moving notes to folders.

## Project layout
Single `app` module for now (split into feature modules once there is enough code to justify it).
`core/` helpers, `data/` Room + repository, `di/` Hilt, `settings/` DataStore, `ui/` screens.

## Build on GitHub from your phone (no Android Studio)
1. Create a GitHub repository.
2. Upload **Advanced-Notes.zip** to the top level (root) of the repository. Do not unzip it.
3. Upload **android-build.yml** to `.github/workflows/android-build.yml` (use "Add file > Create new file", type the path `.github/workflows/android-build.yml`, paste the contents).
4. Open the **Actions** tab > **Android Build** > **Run workflow**. (It also runs on every push.)
5. When it finishes (a few minutes), open the run and download **advanced-notes-debug-apk** under *Artifacts*. Unzip it and install the APK (allow "install unknown apps" for your browser/file manager).
6. If the run fails, open the failed step, copy the error text and send it back - this is expected for a first build.

The workflow installs Gradle 9.8.2 itself and generates the Gradle wrapper if it is missing.

## Signed release APK (optional)
Add four repository secrets (Settings > Secrets and variables > Actions): `KEYSTORE_BASE64` (your keystore file, base64-encoded), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`. Without them the release build is skipped and the summary says so. Never put a keystore inside the ZIP.

## Run tests locally
`./gradlew testDebugUnitTest` (needs JDK 17 and the Android SDK). CI runs this on every build.

## Versions
AGP 9.5.1, Gradle 9.8.2, Kotlin 2.4.21, KSP 2.3.13, Hilt 2.60.1, Room 2.8.5, Compose 1.12.1, Material 3 1.4.0, Navigation 2.10.2, DataStore 1.3.0, JDK 17. compileSdk/targetSdk 37, minSdk 26.

## Known limitations
- M01-M03 were built successfully by GitHub Actions. **The M04-M05 code has not been compiled yet** (no Android SDK or Gradle was available to the author); the next GitHub Actions run is its first build.
- Rich text: overlapping underline and strikethrough on the same text may show only one of them.
- `gradle-wrapper.jar` is not in the ZIP; CI generates it.
- No app icon yet (default Android icon).
- Release build is not minified (R8 off) in v0.01.
