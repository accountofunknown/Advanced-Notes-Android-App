package com.advancednotes.app.core

import com.advancednotes.app.core.markdown.CodeHighlighter
import com.advancednotes.app.core.markdown.CodeKind
import com.advancednotes.app.core.markdown.MarkdownEdit
import com.advancednotes.app.core.markdown.MarkdownHighlighter
import com.advancednotes.app.core.markdown.MarkdownParser
import com.advancednotes.app.core.markdown.MdKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MarkdownTest {
    @Test fun wrapWrapsAndUnwraps() {
        val w = MarkdownEdit.wrap("hello world", 0, 5, "**")
        assertEquals(MarkdownEdit.Edit("**hello** world", 2, 7), w)
        assertEquals(MarkdownEdit.Edit("hello world", 0, 5), MarkdownEdit.wrap(w.text, w.selStart, w.selEnd, "**"))
    }

    @Test fun wrapWithNoSelectionInsertsPair() {
        assertEquals(MarkdownEdit.Edit("a**b", 2, 2), MarkdownEdit.wrap("ab", 1, 1, "*"))
    }

    @Test fun linePrefixToggles() {
        val on = MarkdownEdit.toggleLinePrefix("a\nb", 0, 3, "- ")
        assertEquals("- a\n- b", on.text)
        assertEquals("a\nb", MarkdownEdit.toggleLinePrefix(on.text, 0, on.text.length, "- ").text)
    }

    @Test fun numberedPrefixCountsLines() {
        assertEquals("1. a\n2. b", MarkdownEdit.toggleLinePrefix("a\nb", 0, 3, "", numbered = true).text)
    }

    @Test fun headingSetsChangesAndRemoves() {
        assertEquals("## hello", MarkdownEdit.heading("hello", 2, 2).text)
        assertEquals("hello", MarkdownEdit.heading("## hello", 0, 2).text)
        assertEquals("### x", MarkdownEdit.heading("# x", 0, 3).text)
    }

    @Test fun codeBlockAndLink() {
        val cb = MarkdownEdit.codeBlock("", 0, 0, "kotlin")
        assertEquals("```kotlin\n\n```", cb.text)
        assertEquals(10, cb.selStart)
        val l = MarkdownEdit.link("hi", 0, 2)
        assertEquals("[hi](url)", l.text)
        assertEquals("url", l.text.substring(l.selStart, l.selEnd))
    }

    @Test fun sourceHighlighterFindsStructure() {
        val spans = MarkdownHighlighter.highlight("# Title\n**b** and `c`\n```\ncode\n```")
        assertTrue(spans.any { it.kind == MdKind.HEADING && it.start == 0 && it.end == 7 })
        assertTrue(spans.any { it.kind == MdKind.BOLD && it.start == 8 && it.end == 13 })
        assertTrue(spans.any { it.kind == MdKind.CODE })
        assertTrue(spans.any { it.kind == MdKind.CODE_BLOCK })
    }

    @Test fun codeHighlighterFindsKeywordStringComment() {
        val spans = CodeHighlighter.highlight("val x = \"s\" // c", "kotlin")
        assertTrue(spans.any { it.kind == CodeKind.KEYWORD && it.start == 0 && it.end == 3 })
        assertTrue(spans.any { it.kind == CodeKind.STRING })
        assertTrue(spans.any { it.kind == CodeKind.COMMENT })
    }

    @Test fun outlineListsTopLevelHeadings() {
        val outline = MarkdownParser.outline(MarkdownParser.parse("# Title\n\ntext\n\n## Sub *x*\n"))
        assertEquals(listOf(1, 2), outline.map { it.level })
        assertEquals(listOf("Title", "Sub x"), outline.map { it.title })
        assertEquals(listOf(0, 4), outline.map { it.line })
        assertEquals(listOf(0, 2), outline.map { it.blockIndex })
    }

    @Test fun lineOffsetFindsLineStart() {
        assertEquals(5, MarkdownParser.lineOffset("a\nbb\nc", 2))
    }

    @Test fun tablesAndStrikethroughParse() {
        val doc = MarkdownParser.parse("| a | b |\n| --- | --- |\n| 1 | 2 |\n\n~~gone~~")
        assertEquals(2, MarkdownParser.children(doc).size)
    }
}
