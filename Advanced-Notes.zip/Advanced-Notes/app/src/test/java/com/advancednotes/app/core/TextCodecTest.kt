package com.advancednotes.app.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TextCodecTest {
    @Test fun decodesValidUtf8() {
        assertEquals("h\u00E9llo \u0939\u093F\u0928\u094D\u0926\u0940", TextCodec.decodeUtf8(TextCodec.encodeUtf8("h\u00E9llo \u0939\u093F\u0928\u094D\u0926\u0940")))
    }

    @Test fun rejectsInvalidUtf8() {
        assertNull(TextCodec.decodeUtf8(byteArrayOf(0xC3.toByte(), 0x28)))
    }

    @Test fun stripsBomAndNormalizesLineEndings() {
        val bytes = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + "a\r\nb\rc".toByteArray()
        assertEquals("a\nb\nc", TextCodec.decodeUtf8(bytes))
    }
}
