package com.advancednotes.app.core

import com.advancednotes.app.core.rich.ListEngine
import com.advancednotes.app.core.rich.ListKind
import com.advancednotes.app.core.rich.RichCodec
import com.advancednotes.app.core.rich.RichDoc
import com.advancednotes.app.core.rich.RichSpan
import com.advancednotes.app.core.rich.SpanEngine
import com.advancednotes.app.core.rich.SpanType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SpanEngineTest {
    private val bold = SpanType.BOLD

    @Test fun addMergesAdjacentSpans() {
        val s = SpanEngine.add(SpanEngine.add(emptyList(), bold, 0, 0, 3), bold, 0, 3, 6)
        assertEquals(listOf(RichSpan(0, 6, bold)), s)
    }

    @Test fun removeSplitsSpan() {
        val s = SpanEngine.remove(listOf(RichSpan(0, 10, bold)), bold, 3, 6)
        assertEquals(listOf(RichSpan(0, 3, bold), RichSpan(6, 10, bold)), s)
    }

    @Test fun coversDetectsGaps() {
        val s = listOf(RichSpan(0, 3, bold), RichSpan(5, 8, bold))
        assertTrue(SpanEngine.covers(s, bold, 0, 3))
        assertFalse(SpanEngine.covers(s, bold, 0, 8))
    }

    @Test fun typingAtEndOfSpanExtendsIt() {
        val s = SpanEngine.adjust(listOf(RichSpan(0, 4, bold)), "bold", "boldx")
        assertEquals(listOf(RichSpan(0, 5, bold)), s)
    }

    @Test fun programmaticInsertAtEndDoesNotExtend() {
        val s = SpanEngine.adjust(listOf(RichSpan(0, 4, bold)), "bold", "boldx", inherit = false)
        assertEquals(listOf(RichSpan(0, 4, bold)), s)
    }

    @Test fun insertBeforeShiftsSpan() {
        val s = SpanEngine.adjust(listOf(RichSpan(2, 4, bold)), "abcd", "XXabcd")
        assertEquals(listOf(RichSpan(4, 6, bold)), s)
    }

    @Test fun deletionInsideShrinksAndDeletionOfAllDropsSpan() {
        assertEquals(listOf(RichSpan(0, 3, bold)), SpanEngine.adjust(listOf(RichSpan(0, 4, bold)), "abcd", "abc"))
        assertTrue(SpanEngine.adjust(listOf(RichSpan(1, 3, bold)), "abcd", "ad").isEmpty())
    }

    @Test fun headingAddsSizeAndBold() {
        val s = SpanEngine.setHeading(emptyList(), 0, 5, 1)
        assertTrue(SpanEngine.covers(s, SpanType.BOLD, 0, 5))
        assertEquals(28, s.first { it.type == SpanType.SIZE }.value)
        assertTrue(SpanEngine.setHeading(s, 0, 5, 0).isEmpty())
    }

    @Test fun enterContinuesBulletAndNumberedLists() {
        assertEquals("\u2022 a\n\u2022 " to 6, ListEngine.onEnter("\u2022 a\n", 4))
        assertEquals("1. a\n2. " to 8, ListEngine.onEnter("1. a\n", 5))
    }

    @Test fun enterOnEmptyItemEndsList() {
        assertEquals("" to 0, ListEngine.onEnter("\u2022 \n", 3))
    }

    @Test fun enterOutsideListDoesNothing() {
        assertNull(ListEngine.onEnter("plain\n", 6))
    }

    @Test fun toggleBulletOnTwoLinesAndBack() {
        val (doc, _) = ListEngine.toggle(RichDoc("a\nb", emptyList()), 0, 3, ListKind.BULLET)
        assertEquals("\u2022 a\n\u2022 b", doc.text)
        val (back, _) = ListEngine.toggle(doc, 0, doc.text.length, ListKind.BULLET)
        assertEquals("a\nb", back.text)
    }

    @Test fun toggleCheckedFlipsOnlyChecklistLines() {
        val doc = RichDoc("\u2610 task", emptyList())
        assertEquals("\u2611 task", ListEngine.toggleChecked(doc, 2)!!.text)
        assertNull(ListEngine.toggleChecked(RichDoc("plain", emptyList()), 0))
    }

    @Test fun codecRoundTripsAndFallsBackToPlainText() {
        val doc = RichDoc("hello \"world\"\nline2", listOf(RichSpan(0, 5, bold), RichSpan(6, 9, SpanType.COLOR, -65536)))
        assertEquals(doc, RichCodec.decode(RichCodec.encode(doc)))
        assertEquals(RichDoc("just text", emptyList()), RichCodec.decode("just text"))
        assertNotNull(RichCodec.decode("{broken"))
    }
}
