package com.advancednotes.app.core

import org.junit.Assert.assertEquals
import org.junit.Test

class TextStatsTest {
    @Test fun emptyTextHasNoWords() {
        assertEquals(0, TextStats.wordCount(""))
        assertEquals(0, TextStats.wordCount("   \n\t "))
    }

    @Test fun countsWordsAcrossWhitespace() {
        assertEquals(4, TextStats.wordCount("one  two\nthree\tfour"))
    }

    @Test fun readingTimeRoundsUpAndHasMinimumOfOne() {
        assertEquals(0, TextStats.readingMinutes(0))
        assertEquals(1, TextStats.readingMinutes(1))
        assertEquals(1, TextStats.readingMinutes(200))
        assertEquals(2, TextStats.readingMinutes(201))
    }
}
