package com.advancednotes.app.core.rich

enum class SpanType { BOLD, ITALIC, UNDERLINE, STRIKE, HIGHLIGHT, COLOR, SIZE }

/** A formatted range [start, end) of the document text. [value] is the ARGB color or size in sp. */
data class RichSpan(val start: Int, val end: Int, val type: SpanType, val value: Int = 0)

data class RichDoc(val text: String, val spans: List<RichSpan>)

enum class ListKind { BULLET, NUMBER, CHECK }
