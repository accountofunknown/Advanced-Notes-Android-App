package com.advancednotes.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import com.advancednotes.app.settings.AppSettings
import com.advancednotes.app.settings.ThemeMode

fun isDarkTheme(mode: ThemeMode, systemDark: Boolean): Boolean = when (mode) {
    ThemeMode.LIGHT -> false
    ThemeMode.SYSTEM -> systemDark
    ThemeMode.DARK, ThemeMode.AMOLED -> true
}

@Composable
fun AdvancedNotesTheme(settings: AppSettings, darkTheme: Boolean, content: @Composable () -> Unit) {
    val accent = Color(settings.accent)
    val onAccent = if (accent.luminance() > 0.5f) Color.Black else Color.White
    val scheme = if (!darkTheme) {
        lightColorScheme(primary = accent, onPrimary = onAccent)
    } else {
        val base = darkColorScheme(primary = accent, onPrimary = onAccent)
        if (settings.themeMode == ThemeMode.AMOLED) {
            base.copy(
                background = Color.Black,
                surface = Color.Black,
                surfaceContainerLowest = Color.Black,
                surfaceContainerLow = Color(0xFF0C0C0C),
                surfaceContainer = Color(0xFF121212),
                surfaceContainerHigh = Color(0xFF1A1A1A),
                surfaceContainerHighest = Color(0xFF222222),
            )
        } else base
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
