package com.advancednotes.app.ui.editor

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.advancednotes.app.core.rich.NoteContent
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RevisionsScreen(onBack: () -> Unit, vm: RevisionsViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    var expandedId by remember { mutableStateOf<Long?>(null) }
    val format = remember { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Version history") },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } },
            )
        },
    ) { padding ->
        if (state.items.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding).padding(24.dp), contentAlignment = Alignment.Center) {
                Text("No earlier versions yet. A version is saved automatically as you edit.", style = MaterialTheme.typography.bodyLarge)
            }
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(state.items, key = { it.id }) { rev ->
                    val text = NoteContent.plainText(state.noteType, rev.content)
                    val expanded = expandedId == rev.id
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(format.format(Date(rev.createdAt)), style = MaterialTheme.typography.titleSmall)
                            if (rev.title.isNotBlank()) Text(rev.title, style = MaterialTheme.typography.bodyMedium)
                            Text(if (expanded) text else text.take(160), style = MaterialTheme.typography.bodySmall)
                            Row {
                                TextButton(onClick = { expandedId = if (expanded) null else rev.id }) { Text(if (expanded) "Collapse" else "View") }
                                TextButton(onClick = { vm.restore(rev.id, onBack) }) { Text("Restore") }
                                TextButton(onClick = { vm.delete(rev.id) }) { Text("Delete") }
                            }
                        }
                    }
                }
            }
        }
    }
}
