package com.advancednotes.app.ui.markdown

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import com.advancednotes.app.core.markdown.MarkdownHighlighter
import com.advancednotes.app.core.markdown.MdKind

/** Colors the Markdown source text; the characters themselves are never changed. */
fun markdownSourceStyled(text: String, primary: Color, muted: Color, codeBg: Color, link: Color): AnnotatedString =
    buildAnnotatedString {
        append(text)
        for (s in MarkdownHighlighter.highlight(text)) {
            val style = when (s.kind) {
                MdKind.HEADING -> SpanStyle(color = primary, fontWeight = FontWeight.Bold)
                MdKind.BOLD -> SpanStyle(fontWeight = FontWeight.Bold)
                MdKind.ITALIC -> SpanStyle(fontStyle = FontStyle.Italic)
                MdKind.STRIKE -> SpanStyle(textDecoration = TextDecoration.LineThrough)
                MdKind.CODE -> SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)
                MdKind.CODE_BLOCK -> SpanStyle(fontFamily = FontFamily.Monospace, color = muted)
                MdKind.LINK -> SpanStyle(color = link)
                MdKind.QUOTE -> SpanStyle(color = muted, fontStyle = FontStyle.Italic)
                MdKind.MARKER -> SpanStyle(color = primary, fontWeight = FontWeight.Bold)
            }
            addStyle(style, s.start.coerceIn(0, text.length), s.end.coerceIn(0, text.length))
        }
    }
