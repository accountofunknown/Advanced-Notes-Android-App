package com.advancednotes.app.core

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction

/** Strict UTF-8 handling for importing text files (pure, unit tested). */
object TextCodec {
    /** Returns the text, or null when the bytes are not valid UTF-8. Strips a BOM and normalizes line endings to \n. */
    fun decodeUtf8(bytes: ByteArray): String? = try {
        val text = Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(bytes))
            .toString()
        text.removePrefix("\uFEFF").replace("\r\n", "\n").replace('\r', '\n')
    } catch (e: CharacterCodingException) {
        null
    }

    fun encodeUtf8(text: String): ByteArray = text.toByteArray(Charsets.UTF_8)
}
