package com.advancednotes.app.ui.markdown

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.advancednotes.app.core.markdown.CodeHighlighter
import com.advancednotes.app.core.markdown.CodeKind
import com.advancednotes.app.core.markdown.MarkdownParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.commonmark.ext.gfm.strikethrough.Strikethrough
import org.commonmark.ext.gfm.tables.TableBlock
import org.commonmark.ext.gfm.tables.TableCell
import org.commonmark.ext.gfm.tables.TableRow
import org.commonmark.node.BlockQuote
import org.commonmark.node.BulletList
import org.commonmark.node.Code
import org.commonmark.node.Emphasis
import org.commonmark.node.FencedCodeBlock
import org.commonmark.node.HardLineBreak
import org.commonmark.node.Heading
import org.commonmark.node.HtmlBlock
import org.commonmark.node.HtmlInline
import org.commonmark.node.Image
import org.commonmark.node.IndentedCodeBlock
import org.commonmark.node.Link
import org.commonmark.node.Node
import org.commonmark.node.OrderedList
import org.commonmark.node.Paragraph
import org.commonmark.node.SoftLineBreak
import org.commonmark.node.StrongEmphasis
import org.commonmark.node.ThematicBreak
import org.commonmark.node.Text as MdText

@Immutable
private class MdColors(val link: Color, val codeBg: Color, val bar: Color, val border: Color)

@Composable
private fun rememberMdColors(): MdColors {
    val s = MaterialTheme.colorScheme
    return remember(s) { MdColors(s.primary, s.surfaceContainerHigh, s.primary, s.outlineVariant) }
}

/** Renders Markdown as native Compose content. The source text is never modified. */
@Composable
fun MarkdownPreview(text: String, listState: LazyListState, modifier: Modifier = Modifier) {
    val doc by produceState<Node?>(initialValue = null, text) {
        if (value != null) delay(150)
        value = withContext(Dispatchers.Default) { MarkdownParser.parse(text) }
    }
    val blocks = remember(doc) { doc?.let { MarkdownParser.children(it) } ?: emptyList() }
    val colors = rememberMdColors()
    LazyColumn(
        state = listState,
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        itemsIndexed(blocks) { _, block -> MdBlock(block, colors) }
    }
}

private fun AnnotatedString.Builder.appendChildren(parent: Node, c: MdColors) {
    for (n in MarkdownParser.children(parent)) appendNode(n, c)
}

private fun AnnotatedString.Builder.appendNode(n: Node, c: MdColors) {
    when (n) {
        is MdText -> append(n.literal)
        is SoftLineBreak, is HardLineBreak -> append("\n")
        is Emphasis -> withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { appendChildren(n, c) }
        is StrongEmphasis -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { appendChildren(n, c) }
        is Strikethrough -> withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)) { appendChildren(n, c) }
        is Code -> withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = c.codeBg)) { append(n.literal) }
        is Link -> withLink(
            LinkAnnotation.Url(n.destination, TextLinkStyles(SpanStyle(color = c.link, textDecoration = TextDecoration.Underline))),
        ) { appendChildren(n, c) }
        is Image -> { append("[image: "); appendChildren(n, c); append("]") }
        is HtmlInline -> append(n.literal)
        else -> appendChildren(n, c)
    }
}

@Composable
private fun inlineOf(node: Node, c: MdColors): AnnotatedString =
    remember(node, c) { buildAnnotatedString { appendChildren(node, c) } }

@Composable
private fun headingStyle(level: Int): TextStyle {
    val t = MaterialTheme.typography
    val base = when (level) {
        1 -> t.headlineMedium
        2 -> t.titleLarge
        3 -> t.titleMedium
        else -> t.titleSmall
    }
    return base.copy(fontWeight = FontWeight.Bold)
}

@Composable
private fun MdBlock(node: Node, c: MdColors) {
    when (node) {
        is Heading -> Text(inlineOf(node, c), style = headingStyle(node.level))
        is Paragraph -> Text(inlineOf(node, c), style = MaterialTheme.typography.bodyLarge)
        is BulletList -> MdList(node, ordered = false, c = c)
        is OrderedList -> MdList(node, ordered = true, c = c)
        is BlockQuote -> Row(Modifier.height(IntrinsicSize.Min)) {
            Box(Modifier.fillMaxHeight().width(3.dp).background(c.bar))
            Spacer(Modifier.width(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                MarkdownParser.children(node).forEach { MdBlock(it, c) }
            }
        }
        is FencedCodeBlock -> CodeBlock(node.literal.orEmpty(), node.info.orEmpty(), c)
        is IndentedCodeBlock -> CodeBlock(node.literal.orEmpty(), "", c)
        is ThematicBreak -> HorizontalDivider()
        is TableBlock -> MdTable(node, c)
        is HtmlBlock -> Text(node.literal.orEmpty(), fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
        else -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            MarkdownParser.children(node).forEach { MdBlock(it, c) }
        }
    }
}

@Composable
private fun MdList(list: Node, ordered: Boolean, c: MdColors) {
    val items = remember(list) { MarkdownParser.children(list) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEachIndexed { i, item -> MdListItem(item, if (ordered) "${i + 1}." else "\u2022", c) }
    }
}

@Composable
private fun MdListItem(item: Node, marker: String, c: MdColors) {
    val kids = remember(item) { MarkdownParser.children(item) }
    val first = kids.firstOrNull() as? Paragraph
    val firstText = if (first != null) inlineOf(first, c) else null
    val raw = firstText?.text.orEmpty()
    val task = when {
        raw.startsWith("[ ] ") -> "\u2610"
        raw.startsWith("[x] ") || raw.startsWith("[X] ") -> "\u2611"
        else -> null
    }
    Row {
        Text(task ?: marker, Modifier.width(28.dp))
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            kids.forEachIndexed { i, k ->
                if (i == 0 && firstText != null) {
                    Text(if (task != null) firstText.subSequence(4, firstText.length) else firstText)
                } else {
                    MdBlock(k, c)
                }
            }
        }
    }
}

private fun collectRows(n: Node, out: MutableList<Node>) {
    for (child in MarkdownParser.children(n)) {
        if (child is TableRow) out.add(child) else collectRows(child, out)
    }
}

@Composable
private fun MdTable(table: Node, c: MdColors) {
    val rows = remember(table) { ArrayList<Node>().also { collectRows(table, it) } }
    Column(Modifier.horizontalScroll(rememberScrollState()).border(1.dp, c.border)) {
        rows.forEach { row ->
            Row {
                MarkdownParser.children(row).forEach { cell ->
                    Box(Modifier.width(140.dp).border(0.5.dp, c.border).padding(8.dp)) {
                        Text(
                            inlineOf(cell, c),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = if ((cell as? TableCell)?.isHeader == true) FontWeight.Bold else null,
                        )
                    }
                }
            }
        }
    }
}

private fun copyToClipboard(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("code", text))
}

@Composable
private fun CodeBlock(code: String, lang: String, c: MdColors) {
    val trimmed = code.trimEnd('\n')
    val context = LocalContext.current
    val scheme = MaterialTheme.colorScheme
    val styled = remember(trimmed, lang, scheme) {
        buildAnnotatedString {
            append(trimmed)
            for (s in CodeHighlighter.highlight(trimmed, lang)) {
                val color = when (s.kind) {
                    CodeKind.KEYWORD -> scheme.primary
                    CodeKind.STRING -> scheme.tertiary
                    CodeKind.COMMENT -> scheme.onSurfaceVariant
                    CodeKind.NUMBER -> scheme.secondary
                }
                addStyle(SpanStyle(color = color), s.start, s.end)
            }
        }
    }
    Surface(color = c.codeBg, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
        Column {
            Row(Modifier.fillMaxWidth().padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(lang.ifBlank { "code" }, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f))
                TextButton(onClick = { copyToClipboard(context, trimmed) }) { Text("Copy") }
            }
            Text(
                styled,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                softWrap = false,
                modifier = Modifier.horizontalScroll(rememberScrollState()).padding(start = 12.dp, end = 12.dp, bottom = 12.dp),
            )
        }
    }
}
