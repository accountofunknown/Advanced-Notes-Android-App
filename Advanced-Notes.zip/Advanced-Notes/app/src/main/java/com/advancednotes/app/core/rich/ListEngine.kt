package com.advancednotes.app.core.rich

/** Bullet / numbered / checklist handling using plain-text line prefixes. */
object ListEngine {
    const val BULLET = "\u2022 "
    const val UNCHECKED = "\u2610 "
    const val CHECKED = "\u2611 "
    const val DIVIDER = "\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500"
    private val numberRegex = Regex("^(\\d+)\\. ")

    fun lineStart(text: String, pos: Int): Int = if (pos <= 0) 0 else text.lastIndexOf('\n', pos - 1) + 1

    fun lineEnd(text: String, pos: Int): Int {
        val i = text.indexOf('\n', pos)
        return if (i < 0) text.length else i
    }

    fun markerOf(line: String): String? = when {
        line.startsWith(BULLET) -> BULLET
        line.startsWith(UNCHECKED) -> UNCHECKED
        line.startsWith(CHECKED) -> CHECKED
        else -> numberRegex.find(line)?.value
    }

    private fun kindOf(marker: String?): ListKind? = when (marker) {
        null -> null
        BULLET -> ListKind.BULLET
        UNCHECKED, CHECKED -> ListKind.CHECK
        else -> ListKind.NUMBER
    }

    /**
     * Called after the user typed a newline ending at [cursor]. Continues the list on the new line,
     * or ends the list when the previous item was empty. Returns the new text and cursor, or null.
     */
    fun onEnter(text: String, cursor: Int): Pair<String, Int>? {
        if (cursor < 1 || text[cursor - 1] != '\n') return null
        val prevStart = lineStart(text, cursor - 1)
        val prevLine = text.substring(prevStart, cursor - 1)
        val marker = markerOf(prevLine) ?: return null
        if (prevLine == marker) {
            return (text.substring(0, prevStart) + text.substring(cursor)) to prevStart
        }
        val next = when (kindOf(marker)) {
            ListKind.BULLET -> BULLET
            ListKind.CHECK -> UNCHECKED
            else -> "${marker.dropLast(2).toInt() + 1}. "
        }
        return (text.substring(0, cursor) + next + text.substring(cursor)) to (cursor + next.length)
    }

    /** Toggles [kind] on every line touched by the selection. Returns the new document and cursor. */
    fun toggle(doc: RichDoc, selStart: Int, selEnd: Int, kind: ListKind): Pair<RichDoc, Int> {
        var text = doc.text
        var spans = doc.spans
        val endPos = if (selEnd > selStart && text.getOrNull(selEnd - 1) == '\n') selEnd - 1 else selEnd
        val first = lineStart(text, selStart)
        val last = lineEnd(text, endPos)
        val lines = text.substring(first, last).split('\n')
        val starts = ArrayList<Int>()
        var offset = first
        for (l in lines) { starts.add(offset); offset += l.length + 1 }
        val allHave = lines.all { kindOf(markerOf(it)) == kind }
        var delta = 0
        for (i in lines.indices.reversed()) {
            val strip = markerOf(lines[i])?.length ?: 0
            val add = if (allHave) "" else when (kind) {
                ListKind.BULLET -> BULLET
                ListKind.CHECK -> UNCHECKED
                ListKind.NUMBER -> "${i + 1}. "
            }
            val newText = text.substring(0, starts[i]) + add + text.substring(starts[i] + strip)
            spans = SpanEngine.adjust(spans, text, newText, inherit = false)
            text = newText
            delta += add.length - strip
        }
        return RichDoc(text, spans) to (last + delta)
    }

    /** Flips a checklist line between unchecked and checked; null if the line is not a checklist item. */
    fun toggleChecked(doc: RichDoc, cursor: Int): RichDoc? {
        val s = lineStart(doc.text, cursor)
        val flipped = when {
            doc.text.startsWith(UNCHECKED, s) -> "\u2611"
            doc.text.startsWith(CHECKED, s) -> "\u2610"
            else -> return null
        }
        val newText = doc.text.replaceRange(s, s + 1, flipped)
        return RichDoc(newText, SpanEngine.adjust(doc.spans, doc.text, newText, inherit = false))
    }
}
