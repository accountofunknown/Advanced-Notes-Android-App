package com.advancednotes.app.core.rich

/** Pure span arithmetic for the rich text editor (no Android dependencies; unit tested). */
object SpanEngine {
    fun add(spans: List<RichSpan>, type: SpanType, value: Int, start: Int, end: Int): List<RichSpan> {
        if (end <= start) return spans
        return normalize(remove(spans, type, start, end) + RichSpan(start, end, type, value))
    }

    fun remove(spans: List<RichSpan>, type: SpanType, start: Int, end: Int): List<RichSpan> =
        spans.flatMap { s ->
            if (s.type != type || s.end <= start || s.start >= end) {
                listOf(s)
            } else {
                buildList {
                    if (s.start < start) add(s.copy(end = start))
                    if (s.end > end) add(s.copy(start = end))
                }
            }
        }

    /** True when spans of [type] cover every character of [start, end). */
    fun covers(spans: List<RichSpan>, type: SpanType, start: Int, end: Int): Boolean {
        if (end <= start) return false
        var pos = start
        for (s in spans.filter { it.type == type }.sortedBy { it.start }) {
            if (s.start > pos) break
            if (s.end > pos) pos = s.end
            if (pos >= end) return true
        }
        return pos >= end
    }

    /** Headings = size + bold over the lines; level 0 clears them. */
    fun setHeading(spans: List<RichSpan>, start: Int, end: Int, level: Int): List<RichSpan> {
        var out = remove(remove(spans, SpanType.SIZE, start, end), SpanType.BOLD, start, end)
        if (level == 1 || level == 2) {
            out = add(out, SpanType.SIZE, if (level == 1) 28 else 22, start, end)
            out = add(out, SpanType.BOLD, 0, start, end)
        }
        return out
    }

    private data class Diff(val p: Int, val oldEnd: Int, val newLen: Int)

    private fun diff(old: String, new: String): Diff {
        val maxP = minOf(old.length, new.length)
        var p = 0
        while (p < maxP && old[p] == new[p]) p++
        var suffix = 0
        while (suffix < old.length - p && suffix < new.length - p &&
            old[old.length - 1 - suffix] == new[new.length - 1 - suffix]
        ) suffix++
        return Diff(p, old.length - suffix, new.length - suffix - p)
    }

    /** If [new] is [old] with text inserted (nothing removed), the inserted range. */
    fun insertion(old: String, new: String): IntRange? {
        if (old == new) return null
        val d = diff(old, new)
        return if (d.oldEnd == d.p && d.newLen > 0) d.p until (d.p + d.newLen) else null
    }

    /**
     * Moves spans so they stay attached to the same text after [old] became [new].
     * With [inherit], text typed at the end of a span (or inside it) joins the span.
     */
    fun adjust(spans: List<RichSpan>, old: String, new: String, inherit: Boolean = true): List<RichSpan> {
        if (old == new || spans.isEmpty()) return spans
        val d = diff(old, new)
        val delta = d.newLen - (d.oldEnd - d.p)
        val out = spans.mapNotNull { s ->
            val ns: Int
            val ne: Int
            if (d.oldEnd == d.p) {
                when {
                    s.start >= d.p -> { ns = s.start + delta; ne = s.end + delta }
                    s.end > d.p -> { ns = s.start; ne = s.end + delta }
                    s.end == d.p && inherit -> { ns = s.start; ne = s.end + delta }
                    else -> { ns = s.start; ne = s.end }
                }
            } else {
                ns = when {
                    s.start <= d.p -> s.start
                    s.start >= d.oldEnd -> s.start + delta
                    else -> d.p + d.newLen
                }
                ne = when {
                    s.end <= d.p -> s.end
                    s.end >= d.oldEnd -> s.end + delta
                    else -> d.p
                }
            }
            if (ne > ns) RichSpan(ns, ne, s.type, s.value) else null
        }
        return normalize(out)
    }

    private fun normalize(spans: List<RichSpan>): List<RichSpan> {
        val result = ArrayList<RichSpan>()
        spans.filter { it.end > it.start }.groupBy { it.type to it.value }.forEach { (_, group) ->
            var cur: RichSpan? = null
            for (s in group.sortedBy { it.start }) {
                val c = cur
                if (c != null && s.start <= c.end) {
                    cur = c.copy(end = maxOf(c.end, s.end))
                } else {
                    if (c != null) result.add(c)
                    cur = s
                }
            }
            cur?.let { result.add(it) }
        }
        return result.sortedWith(compareBy({ it.start }, { it.type.ordinal }, { it.end }))
    }
}
