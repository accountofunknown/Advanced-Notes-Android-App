package com.advancednotes.app.ui.editor

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.advancednotes.app.data.NoteRepository
import com.advancednotes.app.data.db.RevisionEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class RevisionsState(val noteType: String = "", val items: List<RevisionEntity> = emptyList())

@HiltViewModel
class RevisionsViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repo: NoteRepository,
) : ViewModel() {
    private val noteId: Long = checkNotNull(savedStateHandle["noteId"])

    val state: StateFlow<RevisionsState> =
        combine(repo.note(noteId), repo.revisions(noteId)) { note, revisions ->
            RevisionsState(note?.note?.type.orEmpty(), revisions)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), RevisionsState())

    fun restore(revisionId: Long, onDone: () -> Unit) {
        viewModelScope.launch {
            repo.restoreRevision(noteId, revisionId)
            onDone()
        }
    }

    fun delete(revisionId: Long) { viewModelScope.launch { repo.deleteRevision(revisionId) } }
}
