package com.advancednotes.app.data.db

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

enum class NoteType { RICH_TEXT, MARKDOWN, PLAIN_TEXT }

@Entity(tableName = "notebooks")
data class NotebookEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long,
)

@Entity(
    tableName = "folders",
    foreignKeys = [ForeignKey(entity = FolderEntity::class, parentColumns = ["id"], childColumns = ["parentId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("parentId")],
)
data class FolderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val parentId: Long? = null,
    val createdAt: Long,
)

@Entity(tableName = "tags", indices = [Index("name", unique = true)])
data class TagEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
)

@Entity(
    tableName = "notes",
    foreignKeys = [
        ForeignKey(entity = FolderEntity::class, parentColumns = ["id"], childColumns = ["folderId"], onDelete = ForeignKey.SET_NULL),
        ForeignKey(entity = NotebookEntity::class, parentColumns = ["id"], childColumns = ["notebookId"], onDelete = ForeignKey.SET_NULL),
    ],
    indices = [Index("folderId"), Index("notebookId"), Index("modifiedAt")],
)
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    /** One of [NoteType] names. */
    val type: String,
    val folderId: Long? = null,
    val notebookId: Long? = null,
    val pinned: Boolean = false,
    val favorite: Boolean = false,
    val archived: Boolean = false,
    /** Non-null = the note is in Trash (soft delete). */
    val trashedAt: Long? = null,
    val createdAt: Long,
    val modifiedAt: Long,
)

/** Shared document body; all three editor modes will read/write this one row. */
@Entity(
    tableName = "documents",
    foreignKeys = [ForeignKey(entity = NoteEntity::class, parentColumns = ["id"], childColumns = ["noteId"], onDelete = ForeignKey.CASCADE)],
)
data class DocumentEntity(
    @PrimaryKey val noteId: Long,
    val content: String,
    val formatVersion: Int = 1,
)

@Entity(
    tableName = "note_tags",
    primaryKeys = ["noteId", "tagId"],
    foreignKeys = [
        ForeignKey(entity = NoteEntity::class, parentColumns = ["id"], childColumns = ["noteId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = TagEntity::class, parentColumns = ["id"], childColumns = ["tagId"], onDelete = ForeignKey.CASCADE),
    ],
    indices = [Index("tagId")],
)
data class NoteTagCrossRef(val noteId: Long, val tagId: Long)

@Entity(
    tableName = "revisions",
    foreignKeys = [ForeignKey(entity = NoteEntity::class, parentColumns = ["id"], childColumns = ["noteId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("noteId")],
)
data class RevisionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val noteId: Long,
    val title: String,
    val content: String,
    val createdAt: Long,
)

data class NoteWithDocument(
    @Embedded val note: NoteEntity,
    @Relation(parentColumn = "id", entityColumn = "noteId") val document: DocumentEntity?,
)
