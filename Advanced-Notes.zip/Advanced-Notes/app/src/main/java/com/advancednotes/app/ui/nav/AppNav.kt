package com.advancednotes.app.ui.nav

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.advancednotes.app.ui.editor.EditorScreen
import com.advancednotes.app.ui.editor.RevisionsScreen
import com.advancednotes.app.ui.home.HomeScreen
import com.advancednotes.app.ui.settings.SettingsScreen

@Composable
fun AppNav() {
    val nav = rememberNavController()
    val noteArg = listOf(navArgument("noteId") { type = NavType.LongType })
    NavHost(navController = nav, startDestination = "home") {
        composable("home") {
            HomeScreen(
                onOpenNote = { id -> nav.navigate("editor/$id") },
                onOpenSettings = { nav.navigate("settings") },
            )
        }
        composable("editor/{noteId}", arguments = noteArg) {
            EditorScreen(
                onBack = { nav.popBackStack() },
                onOpenHistory = { id -> nav.navigate("history/$id") },
            )
        }
        composable("history/{noteId}", arguments = noteArg) {
            RevisionsScreen(onBack = { nav.popBackStack() })
        }
        composable("settings") { SettingsScreen(onBack = { nav.popBackStack() }) }
    }
}
