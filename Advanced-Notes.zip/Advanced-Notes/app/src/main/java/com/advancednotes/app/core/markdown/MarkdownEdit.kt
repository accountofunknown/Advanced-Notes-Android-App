package com.advancednotes.app.core.markdown

import com.advancednotes.app.core.rich.ListEngine

/** Pure text edits behind the Markdown toolbar. Each returns the new text and selection. */
object MarkdownEdit {
    data class Edit(val text: String, val selStart: Int, val selEnd: Int)

    private val numberRegex = Regex("^\\d+\\. ")
    private val headingRegex = Regex("^(#{1,6}) ")

    /** Wraps the selection in [left]/[right]; wraps again to unwrap. With no selection, inserts the pair. */
    fun wrap(text: String, start: Int, end: Int, left: String, right: String = left): Edit {
        val before = text.substring(0, start)
        val sel = text.substring(start, end)
        val after = text.substring(end)
        if (start == end) {
            return Edit(before + left + right + after, start + left.length, start + left.length)
        }
        if (before.endsWith(left) && after.startsWith(right)) {
            val s = start - left.length
            return Edit(before.dropLast(left.length) + sel + after.drop(right.length), s, s + sel.length)
        }
        if (sel.length >= left.length + right.length && sel.startsWith(left) && sel.endsWith(right)) {
            val inner = sel.substring(left.length, sel.length - right.length)
            return Edit(before + inner + after, start, start + inner.length)
        }
        return Edit(before + left + sel + right + after, start + left.length, start + left.length + sel.length)
    }

    /** Adds [prefix] to every selected line, or removes it when all lines already have it. */
    fun toggleLinePrefix(text: String, start: Int, end: Int, prefix: String, numbered: Boolean = false): Edit {
        val endPos = if (end > start && text.getOrNull(end - 1) == '\n') end - 1 else end
        val first = ListEngine.lineStart(text, start)
        val last = ListEngine.lineEnd(text, endPos)
        val lines = text.substring(first, last).split('\n')
        val has = { l: String -> if (numbered) numberRegex.containsMatchIn(l) else l.startsWith(prefix) }
        val all = lines.all(has)
        val out = lines.mapIndexed { i, l ->
            when {
                all && numbered -> l.replaceFirst(numberRegex, "")
                all -> l.removePrefix(prefix)
                numbered -> "${i + 1}. $l"
                else -> prefix + l
            }
        }.joinToString("\n")
        return Edit(text.substring(0, first) + out + text.substring(last), first, first + out.length)
    }

    /** Sets the heading level of the current line; choosing the same level again removes the heading. */
    fun heading(text: String, pos: Int, level: Int): Edit {
        val s = ListEngine.lineStart(text, pos)
        val e = ListEngine.lineEnd(text, pos)
        val line = text.substring(s, e)
        val m = headingRegex.find(line)
        val current = m?.groupValues?.get(1)?.length ?: 0
        val body = if (m != null) line.substring(m.value.length) else line
        val newLine = if (current == level) body else "#".repeat(level) + " " + body
        return Edit(text.substring(0, s) + newLine + text.substring(e), s + newLine.length, s + newLine.length)
    }

    fun codeBlock(text: String, start: Int, end: Int, lang: String): Edit {
        val before = text.substring(0, start)
        val sel = text.substring(start, end)
        val after = text.substring(end)
        val lead = if (before.isEmpty() || before.endsWith("\n")) "" else "\n"
        val open = "$lead```$lang\n"
        val close = "\n```" + if (after.isEmpty() || after.startsWith("\n")) "" else "\n"
        val selStart = start + open.length
        return Edit(before + open + sel + close + after, selStart, selStart + sel.length)
    }

    fun link(text: String, start: Int, end: Int): Edit {
        val before = text.substring(0, start)
        val sel = text.substring(start, end)
        val after = text.substring(end)
        return if (sel.isEmpty()) {
            Edit("$before[text](url)$after", start + 1, start + 5)
        } else {
            val urlStart = start + 1 + sel.length + 2
            Edit("$before[$sel](url)$after", urlStart, urlStart + 3)
        }
    }

    /** Inserts a block snippet (table, rule) on its own line, replacing the selection. */
    fun insertBlock(text: String, start: Int, end: Int, snippet: String): Edit {
        val before = text.substring(0, start)
        val lead = if (before.isEmpty() || before.endsWith("\n")) "" else "\n"
        val inserted = lead + snippet
        return Edit(before + inserted + text.substring(end), start + inserted.length, start + inserted.length)
    }

    const val TABLE = "| Column 1 | Column 2 |\n| --- | --- |\n|  |  |\n"
    const val RULE = "---\n"
}
