package com.advancednotes.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class AdvancedNotesApp : Application()
