package com.advancednotes.app.core.rich

import org.json.JSONArray
import org.json.JSONObject

/** Stores a rich document as JSON: {"v":1,"text":"...","spans":[[start,end,"BOLD",value],...]}. */
object RichCodec {
    fun encode(doc: RichDoc): String {
        val spans = JSONArray()
        doc.spans.forEach { spans.put(JSONArray().put(it.start).put(it.end).put(it.type.name).put(it.value)) }
        return JSONObject().put("v", 1).put("text", doc.text).put("spans", spans).toString()
    }

    /** Never throws: content that is not our JSON is treated as plain text. */
    fun decode(raw: String): RichDoc {
        if (!raw.trimStart().startsWith("{")) return RichDoc(raw, emptyList())
        return try {
            val obj = JSONObject(raw)
            val text = obj.optString("text", "")
            val arr = obj.optJSONArray("spans") ?: JSONArray()
            val spans = ArrayList<RichSpan>()
            for (i in 0 until arr.length()) {
                val a = arr.optJSONArray(i) ?: continue
                val type = SpanType.entries.firstOrNull { it.name == a.optString(2) } ?: continue
                val s = a.optInt(0).coerceIn(0, text.length)
                val e = a.optInt(1).coerceIn(0, text.length)
                if (e > s) spans.add(RichSpan(s, e, type, a.optInt(3)))
            }
            RichDoc(text, spans)
        } catch (e: Exception) {
            RichDoc(raw, emptyList())
        }
    }
}
