package com.advancednotes.app.core

/** Small, pure text helpers (unit tested). */
object TextStats {
    fun wordCount(text: String): Int {
        val trimmed = text.trim()
        return if (trimmed.isEmpty()) 0 else trimmed.split(Regex("\\s+")).size
    }

    /** Reading time at ~200 words per minute; 0 for empty text, otherwise at least 1. */
    fun readingMinutes(words: Int): Int = if (words <= 0) 0 else maxOf(1, (words + 199) / 200)
}
