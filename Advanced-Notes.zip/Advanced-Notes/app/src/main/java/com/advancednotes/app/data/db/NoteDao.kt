package com.advancednotes.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

/** A new version snapshot is kept at most this often while editing. */
private const val REVISION_INTERVAL_MS = 5 * 60 * 1000L
private const val MAX_REVISIONS_PER_NOTE = 50

@Dao
abstract class NoteDao {
    @Transaction
    @Query("SELECT * FROM notes ORDER BY modifiedAt DESC")
    abstract fun observeAll(): Flow<List<NoteWithDocument>>

    @Transaction
    @Query("SELECT * FROM notes WHERE id = :id")
    abstract fun observeById(id: Long): Flow<NoteWithDocument?>

    @Query("SELECT * FROM notes WHERE id = :id")
    abstract suspend fun getNote(id: Long): NoteEntity?

    @Query("SELECT content FROM documents WHERE noteId = :id")
    abstract suspend fun getContent(id: Long): String?

    @Insert
    abstract suspend fun insertNote(note: NoteEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun upsertDocument(document: DocumentEntity)

    @Query("UPDATE notes SET title = :title, modifiedAt = :now WHERE id = :id")
    abstract suspend fun updateTitle(id: Long, title: String, now: Long)

    @Query("UPDATE notes SET pinned = :value WHERE id = :id")
    abstract suspend fun setPinned(id: Long, value: Boolean)

    @Query("UPDATE notes SET favorite = :value WHERE id = :id")
    abstract suspend fun setFavorite(id: Long, value: Boolean)

    @Query("UPDATE notes SET archived = :value WHERE id = :id")
    abstract suspend fun setArchived(id: Long, value: Boolean)

    @Query("UPDATE notes SET trashedAt = :trashedAt WHERE id = :id")
    abstract suspend fun setTrashed(id: Long, trashedAt: Long?)

    @Query("DELETE FROM notes WHERE id = :id")
    abstract suspend fun deleteById(id: Long)

    // ---- revisions ----
    @Insert
    abstract suspend fun insertRevision(revision: RevisionEntity): Long

    @Query("SELECT * FROM revisions WHERE noteId = :noteId ORDER BY createdAt DESC")
    abstract fun observeRevisions(noteId: Long): Flow<List<RevisionEntity>>

    @Query("SELECT * FROM revisions WHERE id = :id")
    abstract suspend fun getRevision(id: Long): RevisionEntity?

    @Query("SELECT MAX(createdAt) FROM revisions WHERE noteId = :noteId")
    abstract suspend fun latestRevisionTime(noteId: Long): Long?

    @Query("DELETE FROM revisions WHERE id = :id")
    abstract suspend fun deleteRevision(id: Long)

    @Query(
        "DELETE FROM revisions WHERE noteId = :noteId AND id NOT IN " +
            "(SELECT id FROM revisions WHERE noteId = :noteId ORDER BY createdAt DESC LIMIT :keep)",
    )
    abstract suspend fun trimRevisions(noteId: Long, keep: Int)

    // ---- transactions ----
    @Transaction
    open suspend fun create(note: NoteEntity, content: String): Long {
        val id = insertNote(note)
        upsertDocument(DocumentEntity(noteId = id, content = content))
        return id
    }

    /** Saves the note; keeps the previous text as a revision at most every 5 minutes. */
    @Transaction
    open suspend fun saveContent(id: Long, title: String, content: String, now: Long) {
        val previous = getContent(id)
        if (!previous.isNullOrBlank() && previous != content) {
            val last = latestRevisionTime(id)
            if (last == null || now - last >= REVISION_INTERVAL_MS) {
                val oldTitle = getNote(id)?.title.orEmpty()
                insertRevision(RevisionEntity(noteId = id, title = oldTitle, content = previous, createdAt = now))
                trimRevisions(id, MAX_REVISIONS_PER_NOTE)
            }
        }
        updateTitle(id, title, now)
        upsertDocument(DocumentEntity(noteId = id, content = content))
    }

    /** Restores a revision. The current text is first saved as a new revision, so nothing is lost. */
    @Transaction
    open suspend fun restoreRevision(noteId: Long, revisionId: Long, now: Long): Boolean {
        val revision = getRevision(revisionId) ?: return false
        val current = getContent(noteId).orEmpty()
        if (current.isNotBlank() && current != revision.content) {
            insertRevision(
                RevisionEntity(noteId = noteId, title = getNote(noteId)?.title.orEmpty(), content = current, createdAt = now),
            )
            trimRevisions(noteId, MAX_REVISIONS_PER_NOTE)
        }
        updateTitle(noteId, revision.title, now)
        upsertDocument(DocumentEntity(noteId = noteId, content = revision.content))
        return true
    }

    @Transaction
    open suspend fun duplicate(id: Long, now: Long): Long? {
        val source = getNote(id) ?: return null
        val copy = source.copy(
            id = 0,
            title = if (source.title.isBlank()) "Untitled (copy)" else source.title + " (copy)",
            pinned = false,
            trashedAt = null,
            createdAt = now,
            modifiedAt = now,
        )
        return create(copy, getContent(id).orEmpty())
    }
}
