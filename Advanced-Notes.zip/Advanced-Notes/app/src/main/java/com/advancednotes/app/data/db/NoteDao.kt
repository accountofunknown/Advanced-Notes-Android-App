package com.advancednotes.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
abstract class NoteDao {
    @Transaction
    @Query("SELECT * FROM notes WHERE trashedAt IS NULL AND archived = 0 ORDER BY pinned DESC, modifiedAt DESC")
    abstract fun observeActive(): Flow<List<NoteWithDocument>>

    @Transaction
    @Query("SELECT * FROM notes WHERE trashedAt IS NOT NULL ORDER BY trashedAt DESC")
    abstract fun observeTrashed(): Flow<List<NoteWithDocument>>

    @Transaction
    @Query("SELECT * FROM notes WHERE id = :id")
    abstract fun observeById(id: Long): Flow<NoteWithDocument?>

    @Insert
    abstract suspend fun insertNote(note: NoteEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun upsertDocument(document: DocumentEntity)

    @Query("UPDATE notes SET title = :title, modifiedAt = :now WHERE id = :id")
    abstract suspend fun updateTitle(id: Long, title: String, now: Long)

    @Query("UPDATE notes SET pinned = :pinned WHERE id = :id")
    abstract suspend fun setPinned(id: Long, pinned: Boolean)

    @Query("UPDATE notes SET trashedAt = :trashedAt WHERE id = :id")
    abstract suspend fun setTrashed(id: Long, trashedAt: Long?)

    @Query("DELETE FROM notes WHERE id = :id")
    abstract suspend fun deleteById(id: Long)

    @Transaction
    open suspend fun create(note: NoteEntity, content: String): Long {
        val id = insertNote(note)
        upsertDocument(DocumentEntity(noteId = id, content = content))
        return id
    }

    @Transaction
    open suspend fun saveContent(id: Long, title: String, content: String, now: Long) {
        updateTitle(id, title, now)
        upsertDocument(DocumentEntity(noteId = id, content = content))
    }
}
