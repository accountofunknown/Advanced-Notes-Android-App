package com.advancednotes.app.core.markdown

enum class CodeKind { KEYWORD, STRING, COMMENT, NUMBER }

data class CodeSpan(val start: Int, val end: Int, val kind: CodeKind)

/** Small, language-agnostic highlighter for fenced code blocks (comments, strings, numbers, keywords). */
object CodeHighlighter {
    /** Languages offered by the code-block menu. */
    val languages = listOf("kotlin", "java", "python", "javascript", "typescript", "json", "bash", "sql", "c", "cpp", "yaml")

    private val keywords = listOf(
        "if", "else", "for", "while", "do", "return", "break", "continue", "when", "switch", "case", "default",
        "fun", "val", "var", "class", "object", "interface", "enum", "data", "sealed", "override", "suspend",
        "import", "package", "from", "as", "def", "lambda", "function", "const", "let", "new", "this", "super", "self",
        "null", "nil", "None", "true", "false", "True", "False", "in", "is", "not", "and", "or", "try", "catch",
        "finally", "throw", "throws", "except", "raise", "with", "async", "await", "yield", "public", "private",
        "protected", "static", "final", "void", "int", "long", "float", "double", "boolean", "char", "string",
        "select", "from", "where", "insert", "update", "delete", "join", "create", "table", "SELECT", "FROM",
        "WHERE", "INSERT", "UPDATE", "DELETE", "JOIN", "CREATE", "TABLE", "echo", "fi", "then", "done",
    ).distinct()

    private fun commentPattern(lang: String): String = when (lang.trim().lowercase()) {
        "python", "py", "sh", "bash", "shell", "yaml", "yml", "ruby", "rb", "toml" -> """#[^\n]*"""
        "sql" -> """--[^\n]*|/\*[\s\S]*?\*/"""
        "html", "xml" -> """<!--[\s\S]*?-->"""
        "json" -> """(?!)"""
        else -> """//[^\n]*|/\*[\s\S]*?\*/"""
    }

    private const val STRING = """"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*'|`(?:\\.|[^`\\])*`"""
    private const val NUMBER = """\b\d+(?:\.\d+)?\b"""

    fun highlight(code: String, lang: String): List<CodeSpan> {
        val regex = Regex("(" + commentPattern(lang) + ")|(" + STRING + ")|(" + NUMBER + ")|(\\b(?:" + keywords.joinToString("|") + ")\\b)")
        val out = ArrayList<CodeSpan>()
        for (m in regex.findAll(code)) {
            val kind = when {
                m.groups[1] != null -> CodeKind.COMMENT
                m.groups[2] != null -> CodeKind.STRING
                m.groups[3] != null -> CodeKind.NUMBER
                else -> CodeKind.KEYWORD
            }
            if (m.range.last >= m.range.first) out.add(CodeSpan(m.range.first, m.range.last + 1, kind))
        }
        return out
    }
}
