package com.advancednotes.app.core.rich

import com.advancednotes.app.data.db.NoteType

object NoteContent {
    /** Human-readable text of a stored document body (used for previews, word counts, sharing). */
    fun plainText(type: String, raw: String): String =
        if (type == NoteType.RICH_TEXT.name) RichCodec.decode(raw).text else raw
}
