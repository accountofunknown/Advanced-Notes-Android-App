package com.advancednotes.app.ui.editor

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.advancednotes.app.settings.AppSettings

/** Above this size line numbers are switched off to keep typing fast. */
private const val LINE_NUMBER_LIMIT = 300_000

/** One number per logical line, shown next to the first visual line of each (so it works with word wrap). */
private fun gutterText(layout: TextLayoutResult?): String {
    if (layout == null) return "1"
    val t = layout.layoutInput.text.text
    val sb = StringBuilder()
    var n = 0
    for (i in 0 until layout.lineCount) {
        if (i > 0) sb.append('\n')
        val s = layout.getLineStart(i)
        if (i == 0 || (s in 1..t.length && t[s - 1] == '\n')) { n++; sb.append(n) }
    }
    return sb.toString()
}

@Composable
fun PlainTextField(vm: EditorViewModel, settings: AppSettings, modifier: Modifier) {
    val scheme = MaterialTheme.colorScheme
    val showNumbers = settings.lineNumbers && vm.textValue.text.length <= LINE_NUMBER_LIMIT
    val style = TextStyle(
        color = scheme.onSurface,
        fontSize = 15.sp,
        lineHeight = 22.sp,
        fontFamily = if (settings.monospace) FontFamily.Monospace else FontFamily.Default,
        lineHeightStyle = LineHeightStyle(LineHeightStyle.Alignment.Center, LineHeightStyle.Trim.None),
    )
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val vScroll = rememberScrollState()
    val hScroll = rememberScrollState()

    BoxWithConstraints(modifier) {
        val screenHeight = maxHeight
        val minFieldWidth = (maxWidth - if (showNumbers) 56.dp else 0.dp).coerceAtLeast(0.dp)
        Row(Modifier.fillMaxSize().verticalScroll(vScroll)) {
            if (showNumbers) {
                Text(
                    remember(layout) { gutterText(layout) },
                    style = style.copy(color = scheme.onSurfaceVariant, textAlign = TextAlign.End),
                    softWrap = false,
                    modifier = Modifier.widthIn(min = 24.dp).padding(end = 8.dp),
                )
            }
            // No wrap: the field sits in a horizontal scroller, so its width is unbounded and lines never wrap.
            Box(Modifier.weight(1f).then(if (settings.wordWrap) Modifier else Modifier.horizontalScroll(hScroll))) {
                BasicTextField(
                    value = vm.textValue,
                    onValueChange = vm::onFieldChange,
                    modifier = (if (settings.wordWrap) Modifier.fillMaxWidth() else Modifier.widthIn(min = minFieldWidth))
                        .heightIn(min = screenHeight),
                    textStyle = style,
                    cursorBrush = SolidColor(scheme.primary),
                    onTextLayout = { layout = it },
                    decorationBox = { inner ->
                        Box {
                            if (vm.textValue.text.isEmpty()) {
                                Text("Start writing\u2026", style = style.copy(color = scheme.onSurfaceVariant))
                            }
                            inner()
                        }
                    },
                )
            }
        }
    }
}
