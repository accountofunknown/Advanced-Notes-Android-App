package com.advancednotes.app.data.db

import androidx.room.Database
import androidx.room.RoomDatabase

/**
 * Version 1. Later milestones add tables (attachments, tasks, reminders, links, ...)
 * through real Room migrations - the database is never recreated destructively.
 */
@Database(
    entities = [
        NotebookEntity::class, FolderEntity::class, TagEntity::class, NoteEntity::class,
        DocumentEntity::class, NoteTagCrossRef::class, RevisionEntity::class,
    ],
    version = 1,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun noteDao(): NoteDao
}
