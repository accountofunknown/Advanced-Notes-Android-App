package com.advancednotes.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.advancednotes.app.data.NoteRepository
import com.advancednotes.app.data.db.NoteType
import com.advancednotes.app.data.db.NoteWithDocument
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class HomeFilter(val label: String) {
    NOTES("Notes"), FAVORITES("Favorites"), ARCHIVE("Archive"), TRASH("Trash")
}

enum class SortOrder(val label: String) {
    MODIFIED("Recently modified"), CREATED("Recently created"), TITLE("Title A\u2013Z"), OLDEST("Oldest first")
}

data class HomeState(
    val notes: List<NoteWithDocument> = emptyList(),
    val filter: HomeFilter = HomeFilter.NOTES,
    val sort: SortOrder = SortOrder.MODIFIED,
)

@HiltViewModel
class HomeViewModel @Inject constructor(private val repo: NoteRepository) : ViewModel() {
    private val filter = MutableStateFlow(HomeFilter.NOTES)
    private val sort = MutableStateFlow(SortOrder.MODIFIED)

    val state: StateFlow<HomeState> = combine(repo.allNotes, filter, sort) { all, f, s ->
        val filtered = all.filter {
            val n = it.note
            when (f) {
                HomeFilter.NOTES -> n.trashedAt == null && !n.archived
                HomeFilter.FAVORITES -> n.trashedAt == null && n.favorite
                HomeFilter.ARCHIVE -> n.trashedAt == null && n.archived
                HomeFilter.TRASH -> n.trashedAt != null
            }
        }
        val comparator: Comparator<NoteWithDocument> = when (s) {
            SortOrder.MODIFIED -> compareByDescending { it.note.modifiedAt }
            SortOrder.CREATED -> compareByDescending { it.note.createdAt }
            SortOrder.TITLE -> compareBy { it.note.title.lowercase() }
            SortOrder.OLDEST -> compareBy { it.note.createdAt }
        }
        val pinnedFirst = compareByDescending<NoteWithDocument> { it.note.pinned && f != HomeFilter.TRASH }
        HomeState(filtered.sortedWith(pinnedFirst.then(comparator)), f, s)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeState())

    fun setFilter(value: HomeFilter) { filter.value = value }
    fun setSort(value: SortOrder) { sort.value = value }

    fun createNote(type: NoteType, onCreated: (Long) -> Unit) {
        viewModelScope.launch { onCreated(repo.createNote(type)) }
    }

    fun togglePin(n: NoteWithDocument) { viewModelScope.launch { repo.setPinned(n.note.id, !n.note.pinned) } }
    fun toggleFavorite(n: NoteWithDocument) { viewModelScope.launch { repo.setFavorite(n.note.id, !n.note.favorite) } }
    fun toggleArchive(n: NoteWithDocument) { viewModelScope.launch { repo.setArchived(n.note.id, !n.note.archived) } }
    fun duplicate(id: Long) { viewModelScope.launch { repo.duplicate(id) } }
    fun moveToTrash(id: Long) { viewModelScope.launch { repo.moveToTrash(id) } }
    fun restore(id: Long) { viewModelScope.launch { repo.restore(id) } }
    fun deleteForever(id: Long) { viewModelScope.launch { repo.deleteForever(id) } }
}
