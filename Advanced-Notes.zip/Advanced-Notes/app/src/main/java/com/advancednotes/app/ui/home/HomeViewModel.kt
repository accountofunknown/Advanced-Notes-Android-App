package com.advancednotes.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.advancednotes.app.data.NoteRepository
import com.advancednotes.app.data.db.NoteWithDocument
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeState(val notes: List<NoteWithDocument> = emptyList(), val showTrash: Boolean = false)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class HomeViewModel @Inject constructor(private val repo: NoteRepository) : ViewModel() {
    private val showTrash = MutableStateFlow(false)

    val state: StateFlow<HomeState> = showTrash
        .flatMapLatest { trash ->
            (if (trash) repo.trashedNotes else repo.activeNotes).map { HomeState(it, trash) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeState())

    fun showTrash(value: Boolean) { showTrash.value = value }

    fun createNote(onCreated: (Long) -> Unit) {
        viewModelScope.launch { onCreated(repo.createNote()) }
    }

    fun togglePin(note: NoteWithDocument) { viewModelScope.launch { repo.setPinned(note.note.id, !note.note.pinned) } }
    fun moveToTrash(id: Long) { viewModelScope.launch { repo.moveToTrash(id) } }
    fun restore(id: Long) { viewModelScope.launch { repo.restore(id) } }
    fun deleteForever(id: Long) { viewModelScope.launch { repo.deleteForever(id) } }
}
