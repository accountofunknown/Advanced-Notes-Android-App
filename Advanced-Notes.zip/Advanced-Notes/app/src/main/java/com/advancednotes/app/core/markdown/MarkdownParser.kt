package com.advancednotes.app.core.markdown

import org.commonmark.ext.gfm.strikethrough.StrikethroughExtension
import org.commonmark.ext.gfm.tables.TablesExtension
import org.commonmark.node.Code
import org.commonmark.node.Heading
import org.commonmark.node.Node
import org.commonmark.node.Text
import org.commonmark.parser.IncludeSourceSpans
import org.commonmark.parser.Parser

data class OutlineItem(val level: Int, val title: String, val line: Int, val blockIndex: Int)

/** CommonMark + GFM tables and strikethrough. Parsing never modifies the stored Markdown source. */
object MarkdownParser {
    private val parser: Parser = Parser.builder()
        .extensions(listOf(TablesExtension.create(), StrikethroughExtension.create()))
        .includeSourceSpans(IncludeSourceSpans.BLOCKS)
        .build()

    fun parse(text: String): Node = parser.parse(text)

    fun children(node: Node): List<Node> {
        val out = ArrayList<Node>()
        var n = node.firstChild
        while (n != null) { out.add(n); n = n.next }
        return out
    }

    fun plainText(node: Node): String {
        val sb = StringBuilder()
        appendText(node, sb)
        return sb.toString()
    }

    private fun appendText(node: Node, sb: StringBuilder) {
        for (c in children(node)) {
            when (c) {
                is Text -> sb.append(c.literal)
                is Code -> sb.append(c.literal)
                else -> appendText(c, sb)
            }
        }
    }

    /** Top-level headings with their source line and their index among the top-level blocks. */
    fun outline(doc: Node): List<OutlineItem> =
        children(doc).mapIndexedNotNull { i, b ->
            if (b is Heading) {
                OutlineItem(b.level, plainText(b).trim(), b.sourceSpans.firstOrNull()?.lineIndex ?: 0, i)
            } else null
        }

    fun lineOffset(text: String, line: Int): Int {
        var off = 0
        repeat(line) {
            val i = text.indexOf('\n', off)
            if (i < 0) return text.length
            off = i + 1
        }
        return off
    }
}
