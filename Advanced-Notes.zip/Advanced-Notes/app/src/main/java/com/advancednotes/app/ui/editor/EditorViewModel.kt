package com.advancednotes.app.ui.editor

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.advancednotes.app.core.rich.ListEngine
import com.advancednotes.app.core.rich.ListKind
import com.advancednotes.app.core.rich.RichCodec
import com.advancednotes.app.core.rich.RichDoc
import com.advancednotes.app.core.rich.RichSpan
import com.advancednotes.app.core.rich.SpanEngine
import com.advancednotes.app.core.rich.SpanType
import com.advancednotes.app.data.NoteRepository
import com.advancednotes.app.data.db.NoteType
import com.advancednotes.app.data.db.NoteWithDocument
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

enum class SaveState { SAVED, SAVING, UNSAVED, FAILED }

private class Snapshot(val text: String, val spans: List<RichSpan>, val selection: TextRange)

/** Shared by the plain text editor and the rich text editor (same document, different note type). */
@HiltViewModel
class EditorViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repo: NoteRepository,
) : ViewModel() {
    val noteId: Long = checkNotNull(savedStateHandle["noteId"])
    private var saveJob: Job? = null
    private val undoStack = ArrayDeque<Snapshot>()
    private val redoStack = ArrayDeque<Snapshot>()
    private var lastEditAt = 0L

    var title by mutableStateOf("")
        private set
    var textValue by mutableStateOf(TextFieldValue(""))
        private set
    var spans by mutableStateOf<List<RichSpan>>(emptyList())
        private set
    var noteType by mutableStateOf(NoteType.PLAIN_TEXT)
        private set
    var loaded by mutableStateOf(false)
        private set
    var saveState by mutableStateOf(SaveState.SAVED)
        private set
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set

    /** Styles toggled with no selection; applied to the next typed text. */
    private var pendingOn by mutableStateOf<Map<SpanType, Int>>(emptyMap())
    private var pendingOff by mutableStateOf<Set<SpanType>>(emptySet())

    val isRich: Boolean get() = noteType == NoteType.RICH_TEXT

    init {
        viewModelScope.launch {
            repo.note(noteId).first()?.let { applyLoaded(it) }
            loaded = true
        }
    }

    private fun applyLoaded(n: NoteWithDocument) {
        noteType = NoteType.entries.firstOrNull { it.name == n.note.type } ?: NoteType.PLAIN_TEXT
        title = n.note.title
        val raw = n.document?.content.orEmpty()
        if (noteType == NoteType.RICH_TEXT) {
            val d = RichCodec.decode(raw)
            textValue = TextFieldValue(d.text)
            spans = d.spans
        } else {
            textValue = TextFieldValue(raw)
            spans = emptyList()
        }
    }

    private fun serialize(): String =
        if (isRich) RichCodec.encode(RichDoc(textValue.text, spans)) else textValue.text

    /** After coming back from History: pick up a restored version if nothing is unsaved. */
    fun reloadIfClean() {
        if (!loaded || saveState != SaveState.SAVED) return
        viewModelScope.launch {
            val n = repo.note(noteId).first() ?: return@launch
            if (n.note.title != title || n.document?.content.orEmpty() != serialize()) {
                applyLoaded(n)
                undoStack.clear()
                redoStack.clear()
                refreshUndo()
            }
        }
    }

    // ---------------------------------------------------------------- editing

    fun onTitleChange(value: String) { title = value; scheduleSave() }

    fun onFieldChange(new: TextFieldValue) {
        val old = textValue
        if (new.text == old.text) {
            if (new.selection != old.selection) { pendingOn = emptyMap(); pendingOff = emptySet() }
            textValue = new
            return
        }
        pushUndo(coalesce = true)
        var text = new.text
        var sel = new.selection
        if (isRich) {
            var sp = SpanEngine.adjust(spans, old.text, new.text, inherit = true)
            SpanEngine.insertion(old.text, new.text)?.let { r ->
                for (t in pendingOff) sp = SpanEngine.remove(sp, t, r.first, r.last + 1)
                for ((t, v) in pendingOn) sp = SpanEngine.add(sp, t, v, r.first, r.last + 1)
                pendingOn = emptyMap()
                pendingOff = emptySet()
            }
            if (new.text.length == old.text.length + 1 && sel.collapsed && sel.start > 0 && new.text[sel.start - 1] == '\n') {
                ListEngine.onEnter(new.text, sel.start)?.let { (t, c) ->
                    sp = SpanEngine.adjust(sp, new.text, t, inherit = false)
                    text = t
                    sel = TextRange(c)
                }
            }
            spans = sp
        }
        textValue = if (text == new.text) new else TextFieldValue(text, sel)
        scheduleSave()
    }

    private fun applyDoc(doc: RichDoc, selection: TextRange) {
        textValue = TextFieldValue(doc.text, selection)
        spans = doc.spans
        scheduleSave()
    }

    // ------------------------------------------------------------- formatting

    fun isActive(type: SpanType): Boolean {
        val sel = textValue.selection
        return if (sel.collapsed) {
            when {
                type in pendingOn -> true
                type in pendingOff -> false
                else -> spans.any { it.type == type && it.start < sel.start && it.end >= sel.start }
            }
        } else {
            SpanEngine.covers(spans, type, sel.min, sel.max)
        }
    }

    fun toggleStyle(type: SpanType) {
        if (!isRich) return
        val sel = textValue.selection
        if (sel.collapsed) {
            if (isActive(type)) { pendingOn = pendingOn - type; pendingOff = pendingOff + type }
            else { pendingOff = pendingOff - type; pendingOn = pendingOn + (type to 0) }
        } else {
            pushUndo(coalesce = false)
            spans = if (SpanEngine.covers(spans, type, sel.min, sel.max)) {
                SpanEngine.remove(spans, type, sel.min, sel.max)
            } else {
                SpanEngine.add(spans, type, 0, sel.min, sel.max)
            }
            scheduleSave()
        }
    }

    /** Sets a text color or size (value != null) or clears it (null). */
    fun setValueStyle(type: SpanType, value: Int?) {
        if (!isRich) return
        val sel = textValue.selection
        if (sel.collapsed) {
            if (value == null) { pendingOn = pendingOn - type; pendingOff = pendingOff + type }
            else { pendingOff = pendingOff - type; pendingOn = pendingOn + (type to value) }
        } else {
            pushUndo(coalesce = false)
            spans = if (value == null) SpanEngine.remove(spans, type, sel.min, sel.max)
            else SpanEngine.add(spans, type, value, sel.min, sel.max)
            scheduleSave()
        }
    }

    fun setHeading(level: Int) {
        if (!isRich) return
        pushUndo(coalesce = false)
        val sel = textValue.selection
        val start = ListEngine.lineStart(textValue.text, sel.min)
        val end = ListEngine.lineEnd(textValue.text, sel.max)
        spans = SpanEngine.setHeading(spans, start, end, level)
        scheduleSave()
    }

    fun toggleList(kind: ListKind) {
        if (!isRich) return
        pushUndo(coalesce = false)
        val sel = textValue.selection
        val (doc, cursor) = ListEngine.toggle(RichDoc(textValue.text, spans), sel.min, sel.max, kind)
        applyDoc(doc, TextRange(cursor))
    }

    fun toggleChecked() {
        if (!isRich) return
        val flipped = ListEngine.toggleChecked(RichDoc(textValue.text, spans), textValue.selection.min)
        if (flipped == null) { toggleList(ListKind.CHECK); return }
        pushUndo(coalesce = false)
        applyDoc(flipped, textValue.selection)
    }

    fun insertDivider() {
        if (!isRich) return
        pushUndo(coalesce = false)
        val sel = textValue.selection
        val atLineStart = sel.min == 0 || textValue.text[sel.min - 1] == '\n'
        replaceInternal(sel.min, sel.max, (if (atLineStart) "" else "\n") + ListEngine.DIVIDER + "\n")
        scheduleSave()
    }

    // ------------------------------------------------------------ undo / redo

    private fun pushUndo(coalesce: Boolean) {
        val now = System.currentTimeMillis()
        val burst = coalesce && undoStack.isNotEmpty() && now - lastEditAt < 1000
        lastEditAt = now
        if (!burst) {
            undoStack.addLast(Snapshot(textValue.text, spans, textValue.selection))
            if (undoStack.size > 100) undoStack.removeFirst()
        }
        redoStack.clear()
        refreshUndo()
    }

    private fun refreshUndo() { canUndo = undoStack.isNotEmpty(); canRedo = redoStack.isNotEmpty() }

    private fun restoreSnapshot(s: Snapshot) {
        textValue = TextFieldValue(s.text, s.selection)
        spans = s.spans
        pendingOn = emptyMap()
        pendingOff = emptySet()
        refreshUndo()
        scheduleSave()
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.addLast(Snapshot(textValue.text, spans, textValue.selection))
        restoreSnapshot(undoStack.removeLast())
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.addLast(Snapshot(textValue.text, spans, textValue.selection))
        restoreSnapshot(redoStack.removeLast())
    }

    // ----------------------------------------------------------- find/replace

    fun matchCount(query: String): Int {
        if (query.isEmpty()) return 0
        val t = textValue.text
        var count = 0
        var i = t.indexOf(query, 0, ignoreCase = true)
        while (i >= 0) { count++; i = t.indexOf(query, i + query.length, ignoreCase = true) }
        return count
    }

    fun findNext(query: String): Boolean {
        if (query.isEmpty()) return false
        val t = textValue.text
        var i = t.indexOf(query, textValue.selection.max, ignoreCase = true)
        if (i < 0) i = t.indexOf(query, 0, ignoreCase = true)
        if (i < 0) return false
        textValue = textValue.copy(selection = TextRange(i, i + query.length))
        return true
    }

    fun replaceCurrent(query: String, replacement: String) {
        val sel = textValue.selection
        if (query.isNotEmpty() && !sel.collapsed &&
            textValue.text.substring(sel.min, sel.max).equals(query, ignoreCase = true)
        ) {
            pushUndo(coalesce = false)
            replaceInternal(sel.min, sel.max, replacement)
            scheduleSave()
        }
        findNext(query)
    }

    fun replaceAll(query: String, replacement: String): Int {
        if (query.isEmpty()) return 0
        val starts = ArrayList<Int>()
        var i = textValue.text.indexOf(query, 0, ignoreCase = true)
        while (i >= 0) { starts.add(i); i = textValue.text.indexOf(query, i + query.length, ignoreCase = true) }
        if (starts.isEmpty()) return 0
        pushUndo(coalesce = false)
        for (s in starts.reversed()) replaceInternal(s, s + query.length, replacement)
        scheduleSave()
        return starts.size
    }

    private fun replaceInternal(start: Int, end: Int, replacement: String) {
        val old = textValue.text
        val new = old.replaceRange(start, end, replacement)
        spans = SpanEngine.adjust(spans, old, new, inherit = false)
        textValue = TextFieldValue(new, TextRange(start + replacement.length))
    }

    // ----------------------------------------------------------------- saving

    /** Debounced autosave: one database write after typing pauses for 600 ms. */
    private fun scheduleSave() {
        saveState = SaveState.UNSAVED
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(600)
            persist()
        }
    }

    private suspend fun persist() {
        saveState = SaveState.SAVING
        saveState = try {
            val content = serialize()
            // NonCancellable: an in-flight write must finish even if the screen closes.
            withContext(NonCancellable) { repo.save(noteId, title, content) }
            SaveState.SAVED
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            SaveState.FAILED
        }
    }

    /** Called when the screen stops: write pending changes immediately. */
    fun flush() {
        if (saveState == SaveState.UNSAVED || saveState == SaveState.FAILED) {
            saveJob?.cancel()
            viewModelScope.launch { persist() }
        }
    }

    override fun onCleared() {
        if (saveState == SaveState.UNSAVED || saveState == SaveState.FAILED) {
            repo.saveAsync(noteId, title, serialize())
        }
    }
}
