package com.advancednotes.app.ui.editor

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.advancednotes.app.data.NoteRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

enum class SaveState { SAVED, SAVING, UNSAVED, FAILED }

@HiltViewModel
class EditorViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repo: NoteRepository,
) : ViewModel() {
    private val noteId: Long = checkNotNull(savedStateHandle["noteId"])
    private var saveJob: Job? = null

    var title by mutableStateOf("")
        private set
    var content by mutableStateOf("")
        private set
    var loaded by mutableStateOf(false)
        private set
    var saveState by mutableStateOf(SaveState.SAVED)
        private set

    init {
        viewModelScope.launch {
            repo.note(noteId).first()?.let {
                title = it.note.title
                content = it.document?.content.orEmpty()
            }
            loaded = true
        }
    }

    fun onTitleChange(value: String) { title = value; scheduleSave() }
    fun onContentChange(value: String) { content = value; scheduleSave() }

    /** Debounced autosave: one database write after typing pauses for 600 ms. */
    private fun scheduleSave() {
        saveState = SaveState.UNSAVED
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(600)
            persist()
        }
    }

    private suspend fun persist() {
        saveState = SaveState.SAVING
        saveState = try {
            // NonCancellable: an in-flight write must finish even if the screen closes.
            withContext(NonCancellable) { repo.save(noteId, title, content) }
            SaveState.SAVED
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            SaveState.FAILED
        }
    }

    /** Called when the screen stops: write pending changes immediately. */
    fun flush() {
        if (saveState == SaveState.UNSAVED || saveState == SaveState.FAILED) {
            saveJob?.cancel()
            viewModelScope.launch { persist() }
        }
    }

    override fun onCleared() {
        if (saveState == SaveState.UNSAVED || saveState == SaveState.FAILED) {
            repo.saveAsync(noteId, title, content)
        }
    }
}
