package com.advancednotes.app.data

import android.content.Context
import android.net.Uri
import com.advancednotes.app.core.TextCodec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/** Reads and writes UTF-8 text through the Android document picker (no storage permission needed). */
object TextFiles {
    const val MAX_IMPORT_BYTES = 5 * 1024 * 1024

    sealed interface ReadResult {
        data class Ok(val text: String) : ReadResult
        data class Failed(val message: String) : ReadResult
    }

    suspend fun read(context: Context, uri: Uri): ReadResult = withContext(Dispatchers.IO) {
        try {
            val stream = context.contentResolver.openInputStream(uri)
                ?: return@withContext ReadResult.Failed("Could not open the file.")
            val bytes = stream.use { input ->
                val out = ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    total += n
                    if (total > MAX_IMPORT_BYTES) return@withContext ReadResult.Failed("The file is larger than 5 MB.")
                    out.write(buffer, 0, n)
                }
                out.toByteArray()
            }
            val text = TextCodec.decodeUtf8(bytes)
            if (text == null) ReadResult.Failed("This file is not valid UTF-8 text.") else ReadResult.Ok(text)
        } catch (e: Exception) {
            ReadResult.Failed("Could not read the file.")
        }
    }

    suspend fun write(context: Context, uri: Uri, text: String): Boolean = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.openOutputStream(uri, "wt")?.use { it.write(TextCodec.encodeUtf8(text)) } != null
        } catch (e: Exception) {
            false
        }
    }
}
