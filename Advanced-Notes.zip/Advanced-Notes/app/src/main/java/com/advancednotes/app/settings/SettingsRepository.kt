package com.advancednotes.app.settings

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

enum class ThemeMode(val label: String) {
    AMOLED("AMOLED Black"), DARK("Dark"), LIGHT("Light"), SYSTEM("System")
}

val AccentPresets: List<Int> = listOf(
    0xFF4F8CFF, 0xFF2EC4B6, 0xFF7BD389, 0xFFFF8A3D, 0xFFFF5C8A, 0xFF9B7BFF,
).map { it.toInt() }

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.AMOLED,
    val accent: Int = AccentPresets.first(),
    val monospace: Boolean = false,
    val lineNumbers: Boolean = true,
    val wordWrap: Boolean = true,
)

private val Context.dataStore by preferencesDataStore(name = "settings")

@Singleton
class SettingsRepository @Inject constructor(@ApplicationContext private val context: Context) {
    private val themeKey = stringPreferencesKey("theme_mode")
    private val accentKey = intPreferencesKey("accent")
    private val monospaceKey = booleanPreferencesKey("plain_monospace")
    private val lineNumbersKey = booleanPreferencesKey("plain_line_numbers")
    private val wordWrapKey = booleanPreferencesKey("plain_word_wrap")

    val settings: Flow<AppSettings> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { prefs ->
            AppSettings(
                themeMode = ThemeMode.entries.firstOrNull { it.name == prefs[themeKey] } ?: ThemeMode.AMOLED,
                accent = prefs[accentKey] ?: AccentPresets.first(),
                monospace = prefs[monospaceKey] ?: false,
                lineNumbers = prefs[lineNumbersKey] ?: true,
                wordWrap = prefs[wordWrapKey] ?: true,
            )
        }

    suspend fun setThemeMode(mode: ThemeMode) { context.dataStore.edit { it[themeKey] = mode.name } }
    suspend fun setAccent(argb: Int) { context.dataStore.edit { it[accentKey] = argb } }
    suspend fun setMonospace(value: Boolean) { context.dataStore.edit { it[monospaceKey] = value } }
    suspend fun setLineNumbers(value: Boolean) { context.dataStore.edit { it[lineNumbersKey] = value } }
    suspend fun setWordWrap(value: Boolean) { context.dataStore.edit { it[wordWrapKey] = value } }
}
