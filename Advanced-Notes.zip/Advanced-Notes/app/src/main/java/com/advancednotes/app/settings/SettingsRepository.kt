package com.advancednotes.app.settings

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

enum class ThemeMode(val label: String) {
    AMOLED("AMOLED Black"), DARK("Dark"), LIGHT("Light"), SYSTEM("System")
}

val AccentPresets: List<Int> = listOf(
    0xFF4F8CFF, 0xFF2EC4B6, 0xFF7BD389, 0xFFFF8A3D, 0xFFFF5C8A, 0xFF9B7BFF,
).map { it.toInt() }

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.AMOLED,
    val accent: Int = AccentPresets.first(),
)

private val Context.dataStore by preferencesDataStore(name = "settings")

@Singleton
class SettingsRepository @Inject constructor(@ApplicationContext private val context: Context) {
    private val themeKey = stringPreferencesKey("theme_mode")
    private val accentKey = intPreferencesKey("accent")

    val settings: Flow<AppSettings> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { prefs ->
            AppSettings(
                themeMode = ThemeMode.entries.firstOrNull { it.name == prefs[themeKey] } ?: ThemeMode.AMOLED,
                accent = prefs[accentKey] ?: AccentPresets.first(),
            )
        }

    suspend fun setThemeMode(mode: ThemeMode) { context.dataStore.edit { it[themeKey] = mode.name } }
    suspend fun setAccent(argb: Int) { context.dataStore.edit { it[accentKey] = argb } }
}
