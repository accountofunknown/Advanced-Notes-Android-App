package com.advancednotes.app.core.markdown

enum class MdKind { HEADING, BOLD, ITALIC, STRIKE, CODE, CODE_BLOCK, LINK, QUOTE, MARKER }

data class MdSpan(val start: Int, val end: Int, val kind: MdKind)

/** Lightweight syntax highlighting for the Markdown source editor (does not change the text). */
object MarkdownHighlighter {
    private val heading = Regex("^#{1,6}\\s")
    private val quote = Regex("^\\s*>")
    private val marker = Regex("^\\s*(?:[-*+]|\\d+\\.)\\s")
    private val inline = listOf(
        MdKind.BOLD to Regex("\\*\\*[^*\\n]+\\*\\*|__[^_\\n]+__"),
        MdKind.ITALIC to Regex("(?<![*\\w])\\*[^*\\s][^*\\n]*\\*(?!\\*)|(?<![_\\w])_[^_\\s][^_\\n]*_(?![_\\w])"),
        MdKind.STRIKE to Regex("~~[^~\\n]+~~"),
        MdKind.CODE to Regex("`[^`\\n]+`"),
        MdKind.LINK to Regex("!?\\[[^\\]\\n]*]\\([^)\\n]*\\)"),
    )

    fun highlight(text: String): List<MdSpan> {
        val out = ArrayList<MdSpan>()
        var offset = 0
        var fence: String? = null
        for (line in text.split('\n')) {
            val trimmed = line.trimStart()
            val f = fence
            if (f != null) {
                if (line.isNotEmpty()) out.add(MdSpan(offset, offset + line.length, MdKind.CODE_BLOCK))
                if (trimmed.startsWith(f)) fence = null
            } else if (trimmed.startsWith("```") || trimmed.startsWith("~~~")) {
                fence = trimmed.take(3)
                out.add(MdSpan(offset, offset + line.length, MdKind.CODE_BLOCK))
            } else {
                if (heading.containsMatchIn(line)) {
                    out.add(MdSpan(offset, offset + line.length, MdKind.HEADING))
                } else {
                    if (quote.containsMatchIn(line)) out.add(MdSpan(offset, offset + line.length, MdKind.QUOTE))
                    marker.find(line)?.let { out.add(MdSpan(offset, offset + it.value.length, MdKind.MARKER)) }
                    for ((kind, regex) in inline) {
                        for (m in regex.findAll(line)) {
                            out.add(MdSpan(offset + m.range.first, offset + m.range.last + 1, kind))
                        }
                    }
                }
            }
            offset += line.length + 1
        }
        return out
    }
}
