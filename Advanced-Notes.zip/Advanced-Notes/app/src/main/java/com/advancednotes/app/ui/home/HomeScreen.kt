package com.advancednotes.app.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.advancednotes.app.core.TextStats
import com.advancednotes.app.data.db.NoteWithDocument

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onOpenNote: (Long) -> Unit,
    onOpenSettings: () -> Unit,
    vm: HomeViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    var confirmDelete by remember { mutableStateOf<Long?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Advanced Notes") },
                actions = { TextButton(onClick = onOpenSettings) { Text("Settings") } },
            )
        },
        floatingActionButton = {
            if (!state.showTrash) {
                FloatingActionButton(onClick = { vm.createNote(onOpenNote) }) {
                    Text("+", style = MaterialTheme.typography.headlineMedium)
                }
            }
        },
    ) { padding ->
        Column(Modifier.padding(padding)) {
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !state.showTrash, onClick = { vm.showTrash(false) }, label = { Text("Notes") })
                FilterChip(selected = state.showTrash, onClick = { vm.showTrash(true) }, label = { Text("Trash") })
            }
            if (state.notes.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        if (state.showTrash) "Trash is empty." else "No notes yet. Tap + to create one.",
                        style = MaterialTheme.typography.bodyLarge,
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(state.notes, key = { it.note.id }) { item ->
                        NoteCard(
                            item = item,
                            inTrash = state.showTrash,
                            onOpen = { onOpenNote(item.note.id) },
                            onPin = { vm.togglePin(item) },
                            onTrash = { vm.moveToTrash(item.note.id) },
                            onRestore = { vm.restore(item.note.id) },
                            onDeleteForever = { confirmDelete = item.note.id },
                        )
                    }
                }
            }
        }
    }

    confirmDelete?.let { id ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Delete permanently?") },
            text = { Text("This note will be removed forever and cannot be restored.") },
            confirmButton = { TextButton(onClick = { vm.deleteForever(id); confirmDelete = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun NoteCard(
    item: NoteWithDocument,
    inTrash: Boolean,
    onOpen: () -> Unit,
    onPin: () -> Unit,
    onTrash: () -> Unit,
    onRestore: () -> Unit,
    onDeleteForever: () -> Unit,
) {
    val content = item.document?.content.orEmpty()
    val words = TextStats.wordCount(content)
    Card(onClick = onOpen, enabled = !inTrash, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                (if (item.note.pinned) "\uD83D\uDCCC " else "") + item.note.title.ifBlank { "Untitled" },
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (content.isNotBlank()) {
                Text(content, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Text("$words words", style = MaterialTheme.typography.labelSmall)
            Row {
                if (inTrash) {
                    TextButton(onClick = onRestore) { Text("Restore") }
                    TextButton(onClick = onDeleteForever) { Text("Delete forever") }
                } else {
                    TextButton(onClick = onPin) { Text(if (item.note.pinned) "Unpin" else "Pin") }
                    TextButton(onClick = onTrash) { Text("Move to Trash") }
                }
            }
        }
    }
}
