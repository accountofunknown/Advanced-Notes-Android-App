package com.advancednotes.app.ui.home

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.advancednotes.app.core.TextStats
import com.advancednotes.app.core.rich.NoteContent
import com.advancednotes.app.data.db.NoteType
import com.advancednotes.app.data.db.NoteWithDocument

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onOpenNote: (Long) -> Unit,
    onOpenSettings: () -> Unit,
    vm: HomeViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var confirmDelete by remember { mutableStateOf<Long?>(null) }
    var sortMenu by remember { mutableStateOf(false) }
    var createMenu by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Advanced Notes") },
                actions = {
                    Box {
                        TextButton(onClick = { sortMenu = true }) { Text("Sort") }
                        DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                            SortOrder.entries.forEach { order ->
                                DropdownMenuItem(
                                    text = { Text((if (order == state.sort) "\u2713 " else "") + order.label) },
                                    onClick = { vm.setSort(order); sortMenu = false },
                                )
                            }
                        }
                    }
                    TextButton(onClick = onOpenSettings) { Text("Settings") }
                },
            )
        },
        floatingActionButton = {
            if (state.filter != HomeFilter.TRASH) {
                Box {
                    FloatingActionButton(onClick = { createMenu = true }) {
                        Text("+", style = MaterialTheme.typography.headlineMedium)
                    }
                    DropdownMenu(expanded = createMenu, onDismissRequest = { createMenu = false }) {
                        DropdownMenuItem(
                            text = { Text("Rich text note") },
                            onClick = { createMenu = false; vm.createNote(NoteType.RICH_TEXT, onOpenNote) },
                        )
                        DropdownMenuItem(
                            text = { Text("Plain text note") },
                            onClick = { createMenu = false; vm.createNote(NoteType.PLAIN_TEXT, onOpenNote) },
                        )
                    }
                }
            }
        },
    ) { padding ->
        Column(Modifier.padding(padding)) {
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                HomeFilter.entries.forEach { f ->
                    FilterChip(selected = state.filter == f, onClick = { vm.setFilter(f) }, label = { Text(f.label) })
                }
            }
            if (state.notes.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        when (state.filter) {
                            HomeFilter.NOTES -> "No notes yet. Tap + to create one."
                            HomeFilter.FAVORITES -> "No favorite notes."
                            HomeFilter.ARCHIVE -> "Archive is empty."
                            HomeFilter.TRASH -> "Trash is empty."
                        },
                        style = MaterialTheme.typography.bodyLarge,
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(state.notes, key = { it.note.id }) { item ->
                        NoteCard(
                            item = item,
                            filter = state.filter,
                            onOpen = { onOpenNote(item.note.id) },
                            onPin = { vm.togglePin(item) },
                            onFavorite = { vm.toggleFavorite(item) },
                            onArchive = { vm.toggleArchive(item) },
                            onDuplicate = { vm.duplicate(item.note.id) },
                            onShare = { shareNote(context, item) },
                            onTrash = { vm.moveToTrash(item.note.id) },
                            onRestore = { vm.restore(item.note.id) },
                            onDeleteForever = { confirmDelete = item.note.id },
                        )
                    }
                }
            }
        }
    }

    confirmDelete?.let { id ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Delete permanently?") },
            text = { Text("This note and its history will be removed forever and cannot be restored.") },
            confirmButton = { TextButton(onClick = { vm.deleteForever(id); confirmDelete = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } },
        )
    }
}

private fun shareNote(context: Context, item: NoteWithDocument) {
    val body = NoteContent.plainText(item.note.type, item.document?.content.orEmpty())
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, item.note.title)
        putExtra(Intent.EXTRA_TEXT, body)
    }
    context.startActivity(Intent.createChooser(intent, "Share note"))
}

@Composable
private fun NoteCard(
    item: NoteWithDocument,
    filter: HomeFilter,
    onOpen: () -> Unit,
    onPin: () -> Unit,
    onFavorite: () -> Unit,
    onArchive: () -> Unit,
    onDuplicate: () -> Unit,
    onShare: () -> Unit,
    onTrash: () -> Unit,
    onRestore: () -> Unit,
    onDeleteForever: () -> Unit,
) {
    val inTrash = filter == HomeFilter.TRASH
    val text = NoteContent.plainText(item.note.type, item.document?.content.orEmpty())
    val words = TextStats.wordCount(text)
    var menu by remember { mutableStateOf(false) }
    val kind = if (item.note.type == NoteType.RICH_TEXT.name) "Rich text" else "Plain text"
    val flags = (if (item.note.pinned) "\uD83D\uDCCC " else "") + (if (item.note.favorite) "\u2605 " else "")

    Card(onClick = onOpen, enabled = !inTrash, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(start = 16.dp, top = 16.dp, end = 8.dp, bottom = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                flags + item.note.title.ifBlank { "Untitled" },
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (text.isNotBlank()) {
                Text(text, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("$kind \u00B7 $words words", style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f))
                Box {
                    TextButton(onClick = { menu = true }) { Text("More") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        if (inTrash) {
                            DropdownMenuItem(text = { Text("Restore") }, onClick = { menu = false; onRestore() })
                            DropdownMenuItem(text = { Text("Delete forever") }, onClick = { menu = false; onDeleteForever() })
                        } else {
                            DropdownMenuItem(text = { Text(if (item.note.pinned) "Unpin" else "Pin") }, onClick = { menu = false; onPin() })
                            DropdownMenuItem(text = { Text(if (item.note.favorite) "Remove favorite" else "Favorite") }, onClick = { menu = false; onFavorite() })
                            DropdownMenuItem(text = { Text("Duplicate") }, onClick = { menu = false; onDuplicate() })
                            DropdownMenuItem(text = { Text(if (item.note.archived) "Unarchive" else "Archive") }, onClick = { menu = false; onArchive() })
                            DropdownMenuItem(text = { Text("Share") }, onClick = { menu = false; onShare() })
                            DropdownMenuItem(text = { Text("Move to Trash") }, onClick = { menu = false; onTrash() })
                        }
                    }
                }
            }
        }
    }
}
