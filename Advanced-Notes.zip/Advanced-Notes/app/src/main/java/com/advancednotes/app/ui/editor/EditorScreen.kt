package com.advancednotes.app.ui.editor

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.advancednotes.app.core.TextStats
import com.advancednotes.app.core.rich.ListKind
import com.advancednotes.app.core.rich.RichSpan
import com.advancednotes.app.core.rich.SpanType

private val TextColors = listOf(
    "Red" to 0xFFE53935.toInt(),
    "Orange" to 0xFFFB8C00.toInt(),
    "Green" to 0xFF43A047.toInt(),
    "Blue" to 0xFF1E88E5.toInt(),
    "Purple" to 0xFF8E24AA.toInt(),
)

private val TextSizes = listOf("Small" to 13, "Large" to 20, "Huge" to 28)

private fun styleFor(s: RichSpan): SpanStyle = when (s.type) {
    SpanType.BOLD -> SpanStyle(fontWeight = FontWeight.Bold)
    SpanType.ITALIC -> SpanStyle(fontStyle = FontStyle.Italic)
    SpanType.UNDERLINE -> SpanStyle(textDecoration = TextDecoration.Underline)
    SpanType.STRIKE -> SpanStyle(textDecoration = TextDecoration.LineThrough)
    SpanType.HIGHLIGHT -> SpanStyle(background = Color(0x66FFEB3B))
    SpanType.COLOR -> SpanStyle(color = Color(s.value))
    SpanType.SIZE -> SpanStyle(fontSize = s.value.sp)
}

private fun buildStyled(text: String, spans: List<RichSpan>): AnnotatedString = buildAnnotatedString {
    append(text)
    for (s in spans) {
        val st = s.start.coerceIn(0, text.length)
        val en = s.end.coerceIn(0, text.length)
        if (en > st) addStyle(styleFor(s), st, en)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    onBack: () -> Unit,
    onOpenHistory: (Long) -> Unit,
    vm: EditorViewModel = hiltViewModel(),
) {
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { vm.flush() }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.reloadIfClean() }

    var showFind by rememberSaveable { mutableStateOf(false) }
    val words = TextStats.wordCount(vm.textValue.text)
    val fieldColors = TextFieldDefaults.colors(
        focusedContainerColor = Color.Transparent,
        unfocusedContainerColor = Color.Transparent,
        focusedIndicatorColor = Color.Transparent,
        unfocusedIndicatorColor = Color.Transparent,
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        when (vm.saveState) {
                            SaveState.SAVED -> "Saved"
                            SaveState.SAVING -> "Saving\u2026"
                            SaveState.UNSAVED -> "Unsaved changes"
                            SaveState.FAILED -> "Save failed"
                        },
                        style = MaterialTheme.typography.labelLarge,
                    )
                },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } },
                actions = {
                    TextButton(onClick = { showFind = !showFind }) { Text("Find") }
                    TextButton(onClick = { onOpenHistory(vm.noteId) }) { Text("History") }
                },
            )
        },
    ) { padding ->
        if (!vm.loaded) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            Column(Modifier.padding(padding).consumeWindowInsets(padding).imePadding()) {
                TextField(
                    value = vm.title,
                    onValueChange = vm::onTitleChange,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Title") },
                    textStyle = MaterialTheme.typography.titleLarge,
                    singleLine = true,
                    colors = fieldColors,
                )
                if (showFind) FindBar(vm)
                Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp)) {
                    val transformation = remember(vm.spans) {
                        VisualTransformation { t -> TransformedText(buildStyled(t.text, vm.spans), OffsetMapping.Identity) }
                    }
                    BasicTextField(
                        value = vm.textValue,
                        onValueChange = vm::onFieldChange,
                        modifier = Modifier.fillMaxSize(),
                        textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        visualTransformation = if (vm.isRich) transformation else VisualTransformation.None,
                        decorationBox = { inner ->
                            Box {
                                if (vm.textValue.text.isEmpty()) {
                                    Text("Start writing\u2026", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                inner()
                            }
                        },
                    )
                }
                Text(
                    "$words words \u00B7 ${TextStats.readingMinutes(words)} min read \u00B7 ${vm.textValue.text.length} characters",
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                )
                EditorToolbar(vm)
            }
        }
    }
}

@Composable
private fun Tool(selected: Boolean = false, enabled: Boolean = true, onClick: () -> Unit, label: @Composable () -> Unit) {
    FilterChip(selected = selected, enabled = enabled, onClick = onClick, label = label)
}

@Composable
private fun EditorToolbar(vm: EditorViewModel) {
    var colorMenu by remember { mutableStateOf(false) }
    var sizeMenu by remember { mutableStateOf(false) }
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Tool(enabled = vm.canUndo, onClick = vm::undo) { Text("Undo") }
        Tool(enabled = vm.canRedo, onClick = vm::redo) { Text("Redo") }
        if (vm.isRich) {
            Tool(vm.isActive(SpanType.BOLD), onClick = { vm.toggleStyle(SpanType.BOLD) }) { Text("B", fontWeight = FontWeight.Bold) }
            Tool(vm.isActive(SpanType.ITALIC), onClick = { vm.toggleStyle(SpanType.ITALIC) }) { Text("I", fontStyle = FontStyle.Italic) }
            Tool(vm.isActive(SpanType.UNDERLINE), onClick = { vm.toggleStyle(SpanType.UNDERLINE) }) { Text("U", textDecoration = TextDecoration.Underline) }
            Tool(vm.isActive(SpanType.STRIKE), onClick = { vm.toggleStyle(SpanType.STRIKE) }) { Text("S", textDecoration = TextDecoration.LineThrough) }
            Tool(vm.isActive(SpanType.HIGHLIGHT), onClick = { vm.toggleStyle(SpanType.HIGHLIGHT) }) { Text("Highlight") }
            Box {
                Tool(vm.isActive(SpanType.COLOR), onClick = { colorMenu = true }) { Text("Color") }
                DropdownMenu(expanded = colorMenu, onDismissRequest = { colorMenu = false }) {
                    TextColors.forEach { (name, argb) ->
                        DropdownMenuItem(
                            text = { Text("\u25CF $name", color = Color(argb)) },
                            onClick = { colorMenu = false; vm.setValueStyle(SpanType.COLOR, argb) },
                        )
                    }
                    DropdownMenuItem(text = { Text("Default color") }, onClick = { colorMenu = false; vm.setValueStyle(SpanType.COLOR, null) })
                }
            }
            Box {
                Tool(vm.isActive(SpanType.SIZE), onClick = { sizeMenu = true }) { Text("Size") }
                DropdownMenu(expanded = sizeMenu, onDismissRequest = { sizeMenu = false }) {
                    TextSizes.forEach { (name, sp) ->
                        DropdownMenuItem(text = { Text(name) }, onClick = { sizeMenu = false; vm.setValueStyle(SpanType.SIZE, sp) })
                    }
                    DropdownMenuItem(text = { Text("Normal size") }, onClick = { sizeMenu = false; vm.setValueStyle(SpanType.SIZE, null) })
                }
            }
            Tool(onClick = { vm.setHeading(1) }) { Text("H1") }
            Tool(onClick = { vm.setHeading(2) }) { Text("H2") }
            Tool(onClick = { vm.setHeading(0) }) { Text("Body") }
            Tool(onClick = { vm.toggleList(ListKind.BULLET) }) { Text("\u2022 List") }
            Tool(onClick = { vm.toggleList(ListKind.NUMBER) }) { Text("1. List") }
            Tool(onClick = { vm.toggleList(ListKind.CHECK) }) { Text("\u2610 List") }
            Tool(onClick = vm::toggleChecked) { Text("\u2611 Tick") }
            Tool(onClick = vm::insertDivider) { Text("\u2500 Line") }
        }
    }
}

@Composable
private fun FindBar(vm: EditorViewModel) {
    var query by rememberSaveable { mutableStateOf("") }
    var replacement by rememberSaveable { mutableStateOf("") }
    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text("Find") },
            )
            Text("${vm.matchCount(query)}", style = MaterialTheme.typography.labelLarge)
            TextButton(onClick = { vm.findNext(query) }) { Text("Next") }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = replacement,
                onValueChange = { replacement = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text("Replace with") },
            )
            TextButton(onClick = { vm.replaceCurrent(query, replacement) }) { Text("Replace") }
            TextButton(onClick = { vm.replaceAll(query, replacement) }) { Text("All") }
        }
    }
}
