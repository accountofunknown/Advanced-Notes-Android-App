package com.advancednotes.app.ui.editor

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.advancednotes.app.core.TextStats
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.rememberCoroutineScope
import com.advancednotes.app.core.markdown.CodeHighlighter
import com.advancednotes.app.core.markdown.MarkdownEdit
import com.advancednotes.app.core.markdown.MarkdownParser
import com.advancednotes.app.core.markdown.OutlineItem
import com.advancednotes.app.data.db.NoteType
import com.advancednotes.app.ui.markdown.MarkdownPreview
import com.advancednotes.app.ui.markdown.markdownSourceStyled
import kotlinx.coroutines.launch
import com.advancednotes.app.core.rich.ListKind
import com.advancednotes.app.core.rich.RichSpan
import com.advancednotes.app.core.rich.SpanType

private val TextColors = listOf(
    "Red" to 0xFFE53935.toInt(),
    "Orange" to 0xFFFB8C00.toInt(),
    "Green" to 0xFF43A047.toInt(),
    "Blue" to 0xFF1E88E5.toInt(),
    "Purple" to 0xFF8E24AA.toInt(),
)

private val TextSizes = listOf("Small" to 13, "Large" to 20, "Huge" to 28)

private fun styleFor(s: RichSpan): SpanStyle = when (s.type) {
    SpanType.BOLD -> SpanStyle(fontWeight = FontWeight.Bold)
    SpanType.ITALIC -> SpanStyle(fontStyle = FontStyle.Italic)
    SpanType.UNDERLINE -> SpanStyle(textDecoration = TextDecoration.Underline)
    SpanType.STRIKE -> SpanStyle(textDecoration = TextDecoration.LineThrough)
    SpanType.HIGHLIGHT -> SpanStyle(background = Color(0x66FFEB3B))
    SpanType.COLOR -> SpanStyle(color = Color(s.value))
    SpanType.SIZE -> SpanStyle(fontSize = s.value.sp)
}

private fun buildStyled(text: String, spans: List<RichSpan>): AnnotatedString = buildAnnotatedString {
    append(text)
    for (s in spans) {
        val st = s.start.coerceIn(0, text.length)
        val en = s.end.coerceIn(0, text.length)
        if (en > st) addStyle(styleFor(s), st, en)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    onBack: () -> Unit,
    onOpenHistory: (Long) -> Unit,
    vm: EditorViewModel = hiltViewModel(),
) {
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { vm.flush() }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.reloadIfClean() }

    var showFind by rememberSaveable { mutableStateOf(false) }
    val words = TextStats.wordCount(vm.textValue.text)
    val fieldColors = TextFieldDefaults.colors(
        focusedContainerColor = Color.Transparent,
        unfocusedContainerColor = Color.Transparent,
        focusedIndicatorColor = Color.Transparent,
        unfocusedIndicatorColor = Color.Transparent,
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        when (vm.saveState) {
                            SaveState.SAVED -> "Saved"
                            SaveState.SAVING -> "Saving\u2026"
                            SaveState.UNSAVED -> "Unsaved changes"
                            SaveState.FAILED -> "Save failed"
                        },
                        style = MaterialTheme.typography.labelLarge,
                    )
                },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } },
                actions = {
                    TextButton(onClick = { showFind = !showFind }) { Text("Find") }
                    TextButton(onClick = { onOpenHistory(vm.noteId) }) { Text("History") }
                },
            )
        },
    ) { padding ->
        if (!vm.loaded) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            Column(Modifier.padding(padding).consumeWindowInsets(padding).imePadding()) {
                TextField(
                    value = vm.title,
                    onValueChange = vm::onTitleChange,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Title") },
                    textStyle = MaterialTheme.typography.titleLarge,
                    singleLine = true,
                    colors = fieldColors,
                )
                if (showFind) FindBar(vm)
                EditorBody(vm, Modifier.weight(1f).fillMaxWidth())
                Text(
                    "$words words \u00B7 ${TextStats.readingMinutes(words)} min read \u00B7 ${vm.textValue.text.length} characters",
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                )
                if (vm.noteType == NoteType.MARKDOWN) MarkdownToolbar(vm) else EditorToolbar(vm)
            }
        }
    }
}

@Composable
private fun Tool(selected: Boolean = false, enabled: Boolean = true, onClick: () -> Unit, label: @Composable () -> Unit) {
    FilterChip(selected = selected, enabled = enabled, onClick = onClick, label = label)
}

@Composable
private fun EditorToolbar(vm: EditorViewModel) {
    var colorMenu by remember { mutableStateOf(false) }
    var sizeMenu by remember { mutableStateOf(false) }
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Tool(enabled = vm.canUndo, onClick = vm::undo) { Text("Undo") }
        Tool(enabled = vm.canRedo, onClick = vm::redo) { Text("Redo") }
        if (vm.isRich) {
            Tool(vm.isActive(SpanType.BOLD), onClick = { vm.toggleStyle(SpanType.BOLD) }) { Text("B", fontWeight = FontWeight.Bold) }
            Tool(vm.isActive(SpanType.ITALIC), onClick = { vm.toggleStyle(SpanType.ITALIC) }) { Text("I", fontStyle = FontStyle.Italic) }
            Tool(vm.isActive(SpanType.UNDERLINE), onClick = { vm.toggleStyle(SpanType.UNDERLINE) }) { Text("U", textDecoration = TextDecoration.Underline) }
            Tool(vm.isActive(SpanType.STRIKE), onClick = { vm.toggleStyle(SpanType.STRIKE) }) { Text("S", textDecoration = TextDecoration.LineThrough) }
            Tool(vm.isActive(SpanType.HIGHLIGHT), onClick = { vm.toggleStyle(SpanType.HIGHLIGHT) }) { Text("Highlight") }
            Box {
                Tool(vm.isActive(SpanType.COLOR), onClick = { colorMenu = true }) { Text("Color") }
                DropdownMenu(expanded = colorMenu, onDismissRequest = { colorMenu = false }) {
                    TextColors.forEach { (name, argb) ->
                        DropdownMenuItem(
                            text = { Text("\u25CF $name", color = Color(argb)) },
                            onClick = { colorMenu = false; vm.setValueStyle(SpanType.COLOR, argb) },
                        )
                    }
                    DropdownMenuItem(text = { Text("Default color") }, onClick = { colorMenu = false; vm.setValueStyle(SpanType.COLOR, null) })
                }
            }
            Box {
                Tool(vm.isActive(SpanType.SIZE), onClick = { sizeMenu = true }) { Text("Size") }
                DropdownMenu(expanded = sizeMenu, onDismissRequest = { sizeMenu = false }) {
                    TextSizes.forEach { (name, sp) ->
                        DropdownMenuItem(text = { Text(name) }, onClick = { sizeMenu = false; vm.setValueStyle(SpanType.SIZE, sp) })
                    }
                    DropdownMenuItem(text = { Text("Normal size") }, onClick = { sizeMenu = false; vm.setValueStyle(SpanType.SIZE, null) })
                }
            }
            Tool(onClick = { vm.setHeading(1) }) { Text("H1") }
            Tool(onClick = { vm.setHeading(2) }) { Text("H2") }
            Tool(onClick = { vm.setHeading(0) }) { Text("Body") }
            Tool(onClick = { vm.toggleList(ListKind.BULLET) }) { Text("\u2022 List") }
            Tool(onClick = { vm.toggleList(ListKind.NUMBER) }) { Text("1. List") }
            Tool(onClick = { vm.toggleList(ListKind.CHECK) }) { Text("\u2610 List") }
            Tool(onClick = vm::toggleChecked) { Text("\u2611 Tick") }
            Tool(onClick = vm::insertDivider) { Text("\u2500 Line") }
        }
    }
}

@Composable
private fun FindBar(vm: EditorViewModel) {
    var query by rememberSaveable { mutableStateOf("") }
    var replacement by rememberSaveable { mutableStateOf("") }
    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text("Find") },
            )
            Text("${vm.matchCount(query)}", style = MaterialTheme.typography.labelLarge)
            TextButton(onClick = { vm.findNext(query) }) { Text("Next") }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = replacement,
                onValueChange = { replacement = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text("Replace with") },
            )
            TextButton(onClick = { vm.replaceCurrent(query, replacement) }) { Text("Replace") }
            TextButton(onClick = { vm.replaceAll(query, replacement) }) { Text("All") }
        }
    }
}

/** Plain, rich and Markdown-source editing all use this one text field (different highlighting). */
@Composable
private fun TextEditorField(vm: EditorViewModel, modifier: Modifier) {
    val scheme = MaterialTheme.colorScheme
    val transformation = remember(vm.spans, vm.noteType, scheme) {
        when (vm.noteType) {
            NoteType.RICH_TEXT -> VisualTransformation { t ->
                TransformedText(buildStyled(t.text, vm.spans), OffsetMapping.Identity)
            }
            NoteType.MARKDOWN -> VisualTransformation { t ->
                TransformedText(
                    markdownSourceStyled(t.text, scheme.primary, scheme.onSurfaceVariant, scheme.surfaceContainerHigh, scheme.tertiary),
                    OffsetMapping.Identity,
                )
            }
            NoteType.PLAIN_TEXT -> VisualTransformation.None
        }
    }
    Box(modifier) {
        BasicTextField(
            value = vm.textValue,
            onValueChange = vm::onFieldChange,
            modifier = Modifier.fillMaxSize(),
            textStyle = TextStyle(color = scheme.onSurface, fontSize = 16.sp),
            cursorBrush = SolidColor(scheme.primary),
            visualTransformation = transformation,
            decorationBox = { inner ->
                Box {
                    if (vm.textValue.text.isEmpty()) {
                        Text("Start writing\u2026", color = scheme.onSurfaceVariant)
                    }
                    inner()
                }
            },
        )
    }
}

@Composable
private fun EditorBody(vm: EditorViewModel, modifier: Modifier) {
    if (vm.noteType != NoteType.MARKDOWN) {
        TextEditorField(vm, modifier.padding(horizontal = 16.dp))
        return
    }
    var mode by rememberSaveable { mutableIntStateOf(0) } // 0 source, 1 preview, 2 split
    var showOutline by rememberSaveable { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    Column(modifier) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            listOf("Source", "Preview", "Split").forEachIndexed { i, label ->
                FilterChip(selected = mode == i, onClick = { mode = i }, label = { Text(label) })
            }
            TextButton(onClick = { showOutline = true }) { Text("Outline") }
        }
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val wide = maxWidth > 600.dp
            val source = Modifier.padding(horizontal = 16.dp)
            when {
                mode == 0 -> TextEditorField(vm, source.fillMaxSize())
                mode == 1 -> MarkdownPreview(vm.textValue.text, listState, Modifier.fillMaxSize())
                wide -> Row(Modifier.fillMaxSize()) {
                    TextEditorField(vm, source.weight(1f).fillMaxSize())
                    MarkdownPreview(vm.textValue.text, listState, Modifier.weight(1f).fillMaxSize())
                }
                else -> Column(Modifier.fillMaxSize()) {
                    TextEditorField(vm, source.weight(1f).fillMaxWidth())
                    HorizontalDivider()
                    MarkdownPreview(vm.textValue.text, listState, Modifier.weight(1f).fillMaxWidth())
                }
            }
        }
    }
    if (showOutline) {
        OutlineDialog(
            text = vm.textValue.text,
            onDismiss = { showOutline = false },
            onPick = { item ->
                showOutline = false
                vm.moveCursor(MarkdownParser.lineOffset(vm.textValue.text, item.line))
                if (mode != 0) scope.launch { listState.animateScrollToItem(item.blockIndex) }
            },
        )
    }
}

@Composable
private fun OutlineDialog(text: String, onDismiss: () -> Unit, onPick: (OutlineItem) -> Unit) {
    val items = remember(text) { MarkdownParser.outline(MarkdownParser.parse(text)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Outline") },
        text = {
            if (items.isEmpty()) {
                Text("No headings yet. Start a line with # to add one.")
            } else {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    items.forEach { item ->
                        TextButton(onClick = { onPick(item) }, modifier = Modifier.padding(start = ((item.level - 1) * 12).dp)) {
                            Text(item.title.ifBlank { "(empty heading)" })
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun MarkdownToolbar(vm: EditorViewModel) {
    var codeMenu by remember { mutableStateOf(false) }
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Tool(enabled = vm.canUndo, onClick = vm::undo) { Text("Undo") }
        Tool(enabled = vm.canRedo, onClick = vm::redo) { Text("Redo") }
        Tool(onClick = { vm.mdHeading(1) }) { Text("H1") }
        Tool(onClick = { vm.mdHeading(2) }) { Text("H2") }
        Tool(onClick = { vm.mdHeading(3) }) { Text("H3") }
        Tool(onClick = { vm.mdWrap("**") }) { Text("B", fontWeight = FontWeight.Bold) }
        Tool(onClick = { vm.mdWrap("*") }) { Text("I", fontStyle = FontStyle.Italic) }
        Tool(onClick = { vm.mdWrap("~~") }) { Text("S", textDecoration = TextDecoration.LineThrough) }
        Tool(onClick = { vm.mdWrap("`") }) { Text("Code") }
        Tool(onClick = vm::mdLink) { Text("Link") }
        Tool(onClick = { vm.mdPrefix("- ") }) { Text("\u2022 List") }
        Tool(onClick = vm::mdNumbered) { Text("1. List") }
        Tool(onClick = { vm.mdPrefix("- [ ] ") }) { Text("\u2610 Task") }
        Tool(onClick = { vm.mdPrefix("> ") }) { Text("Quote") }
        Box {
            Tool(onClick = { codeMenu = true }) { Text("Code block") }
            DropdownMenu(expanded = codeMenu, onDismissRequest = { codeMenu = false }) {
                DropdownMenuItem(text = { Text("No language") }, onClick = { codeMenu = false; vm.mdCodeBlock("") })
                CodeHighlighter.languages.forEach { lang ->
                    DropdownMenuItem(text = { Text(lang) }, onClick = { codeMenu = false; vm.mdCodeBlock(lang) })
                }
            }
        }
        Tool(onClick = { vm.mdInsertBlock(MarkdownEdit.TABLE) }) { Text("Table") }
        Tool(onClick = { vm.mdInsertBlock(MarkdownEdit.RULE) }) { Text("Rule") }
    }
}
