package com.advancednotes.app.data

import com.advancednotes.app.data.db.NoteDao
import com.advancednotes.app.data.db.NoteEntity
import com.advancednotes.app.data.db.NoteType
import com.advancednotes.app.data.db.NoteWithDocument
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NoteRepository @Inject constructor(
    private val dao: NoteDao,
    private val appScope: CoroutineScope,
) {
    val activeNotes: Flow<List<NoteWithDocument>> = dao.observeActive()
    val trashedNotes: Flow<List<NoteWithDocument>> = dao.observeTrashed()

    fun note(id: Long): Flow<NoteWithDocument?> = dao.observeById(id)

    suspend fun createNote(type: NoteType = NoteType.PLAIN_TEXT): Long {
        val now = System.currentTimeMillis()
        return dao.create(NoteEntity(title = "", type = type.name, createdAt = now, modifiedAt = now), "")
    }

    suspend fun save(id: Long, title: String, content: String) =
        dao.saveContent(id, title, content, System.currentTimeMillis())

    /** Fire-and-forget save that survives the caller (e.g. a ViewModel) being destroyed. */
    fun saveAsync(id: Long, title: String, content: String) {
        appScope.launch { runCatching { save(id, title, content) } }
    }

    suspend fun setPinned(id: Long, pinned: Boolean) = dao.setPinned(id, pinned)
    suspend fun moveToTrash(id: Long) = dao.setTrashed(id, System.currentTimeMillis())
    suspend fun restore(id: Long) = dao.setTrashed(id, null)
    suspend fun deleteForever(id: Long) = dao.deleteById(id)
}
