package com.advancednotes.app.data

import com.advancednotes.app.data.db.NoteDao
import com.advancednotes.app.data.db.NoteEntity
import com.advancednotes.app.data.db.NoteType
import com.advancednotes.app.data.db.NoteWithDocument
import com.advancednotes.app.data.db.RevisionEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NoteRepository @Inject constructor(
    private val dao: NoteDao,
    private val appScope: CoroutineScope,
) {
    val allNotes: Flow<List<NoteWithDocument>> = dao.observeAll()

    fun note(id: Long): Flow<NoteWithDocument?> = dao.observeById(id)
    fun revisions(noteId: Long): Flow<List<RevisionEntity>> = dao.observeRevisions(noteId)

    suspend fun createNote(type: NoteType): Long {
        val now = System.currentTimeMillis()
        return dao.create(NoteEntity(title = "", type = type.name, createdAt = now, modifiedAt = now), "")
    }

    suspend fun save(id: Long, title: String, content: String) =
        dao.saveContent(id, title, content, System.currentTimeMillis())

    /** Fire-and-forget save that survives the caller (e.g. a ViewModel) being destroyed. */
    fun saveAsync(id: Long, title: String, content: String) {
        appScope.launch { runCatching { save(id, title, content) } }
    }

    suspend fun duplicate(id: Long): Long? = dao.duplicate(id, System.currentTimeMillis())
    suspend fun setPinned(id: Long, value: Boolean) = dao.setPinned(id, value)
    suspend fun setFavorite(id: Long, value: Boolean) = dao.setFavorite(id, value)
    suspend fun setArchived(id: Long, value: Boolean) = dao.setArchived(id, value)
    suspend fun moveToTrash(id: Long) = dao.setTrashed(id, System.currentTimeMillis())
    suspend fun restore(id: Long) = dao.setTrashed(id, null)
    suspend fun deleteForever(id: Long) = dao.deleteById(id)

    suspend fun restoreRevision(noteId: Long, revisionId: Long) =
        dao.restoreRevision(noteId, revisionId, System.currentTimeMillis())

    suspend fun deleteRevision(revisionId: Long) = dao.deleteRevision(revisionId)
}
